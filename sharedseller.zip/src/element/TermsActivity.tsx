import { Link } from "react-router-dom"

const TermsActivity = () => {

    return <Link to={'/'}>go to main</Link>
}

export default TermsActivity