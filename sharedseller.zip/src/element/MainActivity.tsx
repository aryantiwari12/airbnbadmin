import { Link } from "react-router-dom"

const MainActivity = () => {

    return <Link to={'terms'}>MainActivity</Link>
}

export default MainActivity