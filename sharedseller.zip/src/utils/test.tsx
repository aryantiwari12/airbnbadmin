import henceforthApi from "./henceforthApi"
import defaultImage from '../assets/images/pages/defaultImage.jpg'
import { useEffect, useState } from "react"
import _superagent from "superagent";
import { async } from "@firebase/util";
const superagentPromise = require("superagent-promise");
const superagent = superagentPromise(_superagent, global.Promise);
let imageSize: any
export default (props: any) => {
    const [show, setShow] = useState<any>()
    if (props.size === 'small') imageSize = henceforthApi.API_FILE_ROOT_SMALL
    if (props.size === 'medium') imageSize = henceforthApi.API_FILE_ROOT_MEDIUM
    if (props.size === 'original') imageSize = henceforthApi.API_FILE_ROOT_ORIGINAL
    const fetchImage = async () => {
        //   await fetch(`${imageSize}${props.filename}`, {
        //         method: 'get',
        //         mode: 'no-cors',
        //         headers: {
        //             'Access-Control-Allow-Origin': '*'
        //         },
        //     }).then(response =>{ console.log(response)})
        //         .then(data => {
        //             console.log(data);
        //             setShow('show')
        //         })
        //         .catch(err => {
        //             console.log(err)
        //             setShow('')
        //         });
        // const res = await fetch(`${imageSize}${props.filename}`, {
        //             method: 'get',
        //             mode: 'no-cors',
        //             headers: {
        //                 'Access-Control-Allow-Origin': '*'
        //             },
        //         });
        // const imageBlob = await res.blob();
        // const imageB= await res;
        // console.log('imageBlob',imageBlob);
        // console.log('imageB',imageB);
        // console.log('res',res);

        // const imageObjectURL = URL.createObjectURL(imageBlob);
        // console.log(imageObjectURL);
        // const req = new Request(imageSize + `${props.filename}`, {
        //     method: 'GET',
        //     mode: 'no-cors',
        //     headers: {
        //         'pragma': 'no-cache',
        //         'cache-control': 'no-cache',
        //         'Access-Control-Allow-Origin': '*'
        //     }
        // });
        try {
            const res= await fetch("https://unsplash.com/images/stock/high-resolution")
            console.log('response', res);
            setShow(imageSize + props.filename)
        } catch (err) {
            console.log('err', err);
            // setShow(null)
        }
        // .then(res => {
        //     if (res.ok) {
        //         console.log('response', res);
        //         return res
        //     } else {
        //         console.log('response', res);

        //         return Promise.reject(res.status)
        //     }
        // }).catch((err) => {
        //     console.log('err', err);

        // })
        // .then(response => response)
        // .then(function (response) {
        // var objectURL = URL.createObjectURL(response);
        // console.log('blo',objectURL.slice(5));

        // setShow(objectURL.slice(5))
        // });
        // setShow(imageObjectURL);
        // superagent.get(`${imageSize}${props.filename}`).then((res: any) => console.log(res.body))
    }
    useEffect(() => {
        // if (props.filename) {
        fetchImage()
        // }
    }, [])

    return <img src={show?show:defaultImage} />
}