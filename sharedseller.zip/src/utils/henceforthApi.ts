import _superagent from "superagent";
const superagentPromise = require("superagent-promise");
const superagent = superagentPromise(_superagent, global.Promise);

// const API_ROOT = `https://${(window.origin.includes('staging') || window.origin.includes('localhost')) ? `staging.` : window.origin.includes('production') ? `production.` : ``}v3nus.io:3000/`;

const API_ROOT = `https://${(window.location.origin.includes('demo') ? 'demo.' : ``)}sharedecommerce.henceforthsolutions.com:3004/`
const API_ROOT_IMAGEUPLOAD = `https://sharedecommerce.nyc3.digitaloceanspaces.com/sharedecommerce/`
const BUCKET_ROOT = `https://sharedecommerce.nyc3.digitaloceanspaces.com/sharedecommerce/`;

const API_FILE_ROOT_MEDIUM = `${BUCKET_ROOT}medium/`;
const API_FILE_ROOT_ORIGINAL = `${BUCKET_ROOT}original/`;
const API_FILE_ROOT_SMALL = `${BUCKET_ROOT}small/`;
// const API_FILE_ROOT_AUDIO = `${BUCKET_ROOT}audio/`;
// const API_FILE_ROOT_VIDEO = `${BUCKET_ROOT}video/`;
// const API_FILE_ROOT_DOCUMENTS = `${BUCKET_ROOT}documents/`;

// const encode = encodeURIComponent;
const responseBody = (res: any) => res.body;

let token: any = null;
const tokenPlugin = (req: any) => {
  if (token) {
    req.set("token", `${token}`);
  }
};

const requests = {
  del: (url: string) =>
    superagent.del(`${API_ROOT}${url}`).use(tokenPlugin).then(responseBody),
  get: (url: string) =>
    superagent.get(`${API_ROOT}${url}`).use(tokenPlugin).then(responseBody),
  put: (url: string, body: any) =>
    superagent
      .put(`${API_ROOT}${url}`, body)
      .use(tokenPlugin)
      .then(responseBody),
  patch: (url: string, body: any) =>
    superagent
      .patch(`${API_ROOT}${url}`, body)
      .use(tokenPlugin)
      .then(responseBody),
  post: (url: string, body: any) =>
    superagent
      .post(`${API_ROOT}${url}`, body)
      .use(tokenPlugin)
      .then(responseBody),
  file: (url: string, key: string, file: File) =>
    superagent.post(`${API_ROOT}${url}`)
      .attach(key, file)
      .use(tokenPlugin)
      .then(responseBody)
};

const Auth = {
  login: (info: any) => requests.post("Seller/login", info),
  signup: (info: any) => requests.post("Seller/signup", info),
  forgotPassword: (info: any) => requests.post("Seller/forgot_password", info),
  checkOtp: (info: any) => requests.post("Seller/forgot_password/verify_otp", info),
  emailVerifySendOtp: (info: any) => requests.post("Seller/resend_otp", info),
  emailVerifyOtp: (info: any) => requests.post("Seller/email/verification", info),
  resendOtp: (info: any) => requests.post("Seller/forgot_password/resend_otp", info),
  resetPassword: (info: any) => requests.post("Seller/forgot_password/set_password", info),
  changePassword: (info: any) => requests.put("Seller/change_password", info),
  editProfile: (info: any) => requests.put("Seller/edit_profile", info),
  loginAsUser: (info: any) => requests.post("Admin/seller/login_as_seller", info),
};
const Notification = {
  getNotification: (pagination: any, limit: any) => {
    return requests.get(
      `Seller/notifications?language=ENGLISH&pagination=${pagination}&limit=${limit}`
    );
  },
  markAsRead: (info: any, id: string) => requests.put(`Seller/notification/read/${id}?language=ENGLISH`, info),
  markAllAsRead: (info: any) => requests.put("Seller/notifications?language=ENGLISH", info),
  clearAllNotification: (info: any) => requests.put("Seller/notifications/clear?language=ENGLISH", info)
}
const Dashboard = {
  getTotalOrderCount: () =>
    requests.get(
      `Seller/dashboard?language=${String("ENGLISH")}`
    ),

  getGraph: (graph: string, type: string) =>
    requests.get(
      `Seller/graph/${graph}?language=ENGLISH&type=${type}`
    ),
};
const Order = {
  export: (start_date: number, end_date: number, q: any) => requests.get(`Seller/orders?language=ENGLISH&start_date=${start_date}&end_date=${end_date}${q ? q : ''}`),

  getOrderList: (pagination: any, limit: any, q: any) => {
    return requests.get(
      `Seller/orders?language=ENGLISH&pagination=${pagination}&limit=${limit}${q ? `&${q}` : ''}`
    );
  },
  getOrderDetails: (id: any) => {
    return requests.get(
      `Seller/orders/${id}?language=ENGLISH`
    );
  },
  getOrderRatingReview: (pagination: any, limit: any, q: any) => {
    return requests.get(
      `Seller/order/reviews?language=ENGLISH&pagination=${pagination}&limit=${limit}${q ? `&${q}` : ''}`
    );
  },
  getOrderInvoiceDetails: (id: any) => {
    return requests.get(
      `Seller/orders/invoice/${id}?language=ENGLISH`
    );
  },
  deleteOrder: (info: any) => requests.put("Seller/orders/cancel", info),
  editCancelOrder: (info: any) => requests.put("Seller/order/cancel/request", info),

}
const Delivery = {
  changesStatus: (info: any) => requests.put("Seller/orders", info),
}
const Transaction = {
  export: (start_date: number, end_date: number) => requests.get(`Seller/transactions?language=ENGLISH&start_date=${start_date}&end_date=${end_date}`),

  getTransactions: (pagination: number, limit: number, q: any) => {
    return requests.get(
      `Seller/transactions?language=ENGLISH&pagination=${pagination}&limit=${limit}${q ? `&${q}` : ''}`
    );
  },
}
const Product = {
  export: (start_date: number, end_date: number) => requests.get(`Seller/products?language=ENGLISH&start_date=${start_date}&end_date=${end_date}`),

  getProductList: (search: string, pagination: any, limit: any, q: any) => {
    return requests.get(
      `Seller/products?language=ENGLISH${search ? `&search=${search}` : ''}${pagination ? `&pagination=${pagination}` : ''}${limit ? `&limit=${limit}` : ''}${q ? `&${q}` : ""}`
    );
  },
  getProductDetails: (id: any) => {
    return requests.get(
      `Seller/products/${id}?language=ENGLISH`
    );
  },
  getProductDetailsAllDynamics: (dynamicUrl: string, id: string | undefined, product_id: string | undefined) => {
    return requests.get(
      `Seller/products/${dynamicUrl}?${id ? `_id=${id}&` : ""}${product_id ? `product_id=${product_id}&` : ""}language=ENGLISH`
    );
  },
  add: (info: any) => requests.post("Seller/products", info),
  editProduct: (info: any) => requests.put("Seller/products", info),
  editProductDetailsDynamically: (dynamicUrl: string, info: any) => requests.put(`Seller/products/${dynamicUrl}`, info),
  deleteProductDetailsDynamically: (dynamicUrl: string, id: string) => requests.del(`Seller/products/${dynamicUrl}/${id}`),
  addProductDetailsDynamically: (dynamicUrl: string, info: any) => requests.post(`Seller/products/${dynamicUrl}`, info),
}

const Common = {
  getProductFilter: () => {
    return requests.get(
      `User/nested`
    );
  },
  do_spaces_file_upload: (key: string, file: any) =>
    requests.file(`Upload/do_spaces_file_upload`, key, file),
  do_spaces_file_upload_multiple: (key: any, file: any) =>
    requests.file(`Upload/do_spaces_file_upload_multiple`, key, file),
};
const Coupons = {
  addCoupon: (info: any) => requests.post("Seller/coupon", info),
  editCoupon: (info: any) => requests.put("Seller/coupon", info),
  getCoupon: (id: string | undefined) => { return requests.get(`Seller/coupon/${id}`) },
  deleteCoupon: (id: string) => requests.del(`Seller/coupon/${id}`),
  getCouponList: (pagination: any, limit: any, q: any) => {
    return requests.get(
      `Seller/coupon?language=ENGLISH${pagination >= 0 ? `&pagination=${pagination}` : ''}${limit ? `&limit=${limit}` : ''}${q ? `&${q}` : ""}`
    );
  },
}
const categorylisting = {
  Brandlisting: () =>
    requests.get(
      `Product/brands`
    ),
  parcelListing: () =>
    requests.get(
      `Seller/shippo/parcel?language=ENGLISH`
    ),
  categorylisting: () =>
    requests.get(
      `Product/categories?language=ENGLISH`
    ),
  subCategorylisting: (id: any) =>
    requests.get(
      `Product/subcategories?category_id=${id}&language=ENGLISH`
    ),
  subSubCategorylisting: (id: any) =>
    requests.get(
      `Product/sub_subcategories?subcategory_id=${id}&language=ENGLISH`
    ),
}
// eslint-disable-next-line 
export default {
  token,
  Auth,
  categorylisting,
  Common,
  Coupons,
  Dashboard,
  Delivery,
  Notification,
  Order,
  Product,
  Transaction,
  API_ROOT,
  API_ROOT_IMAGEUPLOAD,
  API_FILE_ROOT_SMALL,
  API_FILE_ROOT_MEDIUM,
  API_FILE_ROOT_ORIGINAL,
  // API_FILE_ROOT_VIDEO,
  setToken: (_token: any) => {
    token = _token;
  },
};