import { useLocation, useNavigate } from "react-router-dom"

const location = useLocation()
const navigate = useNavigate()
const newParam = new URLSearchParams(location.search)
const handleSearch = (name: string, value: string) => {
    if (value) {
        if (name === "product_id") newParam.delete("search")
        if (name === "search") newParam.delete("product_id")
        if (name === "order_status") newParam.delete("payment_status")
        if (name === "payment_status") newParam.delete("order_status")
        if (name === 'start_date') newParam.delete('end_date')
        if (name === 'stock') newParam.delete('order_status'); newParam.delete('payment_status')
        if (name === 'order_status') newParam.delete('stock'); newParam.delete('payment_status')
        if (name === 'payment_status') newParam.delete('order_status'); newParam.delete('stock')
        newParam.set(name, value)
    } else {
        if (newParam.has(name)) {
            newParam.delete(name)
        }
        if (name === 'start_date') {
            newParam.delete('end_date')
        }

    }
    if (location.pathname.startsWith('/orders')) {
        navigate({
            pathname: "/orders/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/order/cancellation/requests')) {
        navigate({
            pathname: "/order/cancellation/requests/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/ratings')) {
        navigate({
            pathname: "/ratings/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/earnings')) {
        navigate({
            pathname: "/earnings/1",
            search: newParam.toString()
        })
    } else {
        navigate({
            pathname: "/products/1",
            search: newParam.toString()
        })
    }
}
const onChangePagination = (page: number) => {
    if (location.pathname.startsWith('/orders')) {
        navigate({
            pathname: `/orders/${page}`,
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/coupons')) {
        navigate({
            pathname: `/coupons/${page}`,
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/order/cancellation/requests')) {
        navigate({
            pathname: "/order/cancellation/requests/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/ratings')) {
        navigate({
            pathname: "/ratings/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/earnings')) {
        navigate({
            pathname: "/earnings/1",
            search: newParam.toString()
        })
    } else {
        navigate({
            pathname: `/products/${page}`,
            search: newParam.toString()
        })
    }

}
const onFilterPriceHandler = (min_price: string, max_price: string) => {
    if (min_price && max_price) {
        newParam.set("min_price", min_price)
        newParam.set("max_price", max_price)

    } else {
        if (newParam.has("min_price") && newParam.has("max_price")) {
            newParam.delete("min_price")
            newParam.delete("max_price")
        }
    }
    if (location.pathname.startsWith('/orders')) {
        navigate({
            pathname: "/orders/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/order/cancellation/requests')) {
        navigate({
            pathname: "/order/cancellation/requests/1?order_status=CANCELLED",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/ratings')) {
        navigate({
            pathname: "/ratings/1",
            search: newParam.toString()
        })
    } else if (location.pathname.startsWith('/earnings')) {
        navigate({
            pathname: "/earnings/1",
            search: newParam.toString()
        })
    } else {
        navigate({
            pathname: "/products/1",
            search: newParam.toString()
        })
    }
}
export {
    handleSearch,
    onFilterPriceHandler,
    onChangePagination
}