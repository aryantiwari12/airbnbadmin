import '../../assets/styles/pages.scss'
import '../../assets/styles/auth.scss'
import { Link, useMatch } from 'react-router-dom'
import BreadCrumb from '../../components/common/BreadCrumb';
import { Fragment, useContext, useEffect, useState } from 'react';
import PaginationLayout from '../../components/common/PaginationLayout';
import { GlobalContext, handleError } from '../../context/Provider';
import henceforthApi from '../../utils/henceforthApi';
import Spinner from '../../components/common/spinner';
import moment from 'moment';
import Swal from 'sweetalert2';
const CouponListing = () => {
    const { loading, setLoading, authState, authDispatch } = useContext(GlobalContext)
    let Limit = 10
    henceforthApi.setToken(authState.access_token)
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Coupons list', url: ``, active: 'not-allowed' },
    ]
    const match = useMatch('/coupons/:page')
    const [couponList, setCouponList] = useState({
        total_count: 0,
        list: []
    })
    const couponListing = async () => {

        setLoading(true)
        try {
            let res = (await henceforthApi.Coupons.getCouponList(Number(match?.params.page) - 1, Limit, '')).data
            setCouponList({
                ...couponList,
                total_count: res.total_count,
                list: res.data,
            })

        } catch (err) {
            console.log("err", err);
            handleError(err, '', authDispatch);

        } finally {
            setLoading(false)
        }
    }
    useEffect(() => {
        couponListing();

    }, [])
    // const changeDate=(res:string)=>{
    //     let x= String(new Date(res).toLocaleString("en-us",{day:}, { month: "short" }))
    //     return x
    // }
    const deleteCoupon = async (id: string) => {
        Swal.fire({
            title: 'Are you sure?',
            text: "you want to delete this Coupon?",
            icon: 'warning',
            confirmButtonColor: '#3085d6',
            showDenyButton: true,
            denyButtonText: 'No',
            confirmButtonText: 'Yes'
        }).then(async (result) => {

            if (result.isConfirmed) {
                try {
                    await henceforthApi.Coupons.deleteCoupon(id)
                    couponListing()
                    Swal.fire(
                        'Deleted!',
                        'Your Coupon has been deleted.',
                        'success')
                } catch (err: any) {
                    console.log(err.response.body.error_description);
                    handleError(err, 'active', authDispatch);
                }
            }
        })
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing'>
                <section className='products'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-md-12">
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Coupons</h5>
                                    </div>
                                    <div className="common-card-content">
                                        {/* table */}
                                        <div className='data-list-table table-responsive mb-3 text-center'>
                                            {loading ? <Spinner color={"text-success"} /> :
                                                <table className="table table-striped align-middle">
                                                    <thead className=''>
                                                        <tr>
                                                            <th>Sr No</th>
                                                            <th>Coupon Name</th>
                                                            <th>Type</th>
                                                            <th>Sub Type</th>
                                                            <th>Price</th>
                                                            <th>Max Discount</th>
                                                            <th>Percentage</th>
                                                            <th>Start Date</th>
                                                            <th>End Date</th>
                                                            <th>Action</th>
                                                        </tr>
                                                    </thead>
                                                    <tbody>
                                                        {Array.isArray(couponList.list) && couponList.list.length ? couponList.list.map((res: any, index) => <tr key={res?._id}>
                                                            <td>{index + 1}</td>
                                                            <td>{res?.name ? res?.name : ''}</td>
                                                            <td>{res?.type ? res?.type : ''}</td>
                                                            <td>{res?.sub_type ? res?.sub_type : ''}</td>
                                                            <td> {res?.price ? <><b>&#36;</b>{res?.price}</> : 'Not required'}</td>
                                                            <td>{res?.max_discount ? <><b>&#36;</b>{res?.max_discount}</> : 'Not required'}</td>
                                                            <td> {res?.percentage ? <>{res?.percentage}%</> : 'Not required'}</td>
                                                            <td>{res?.start_date ? moment(res?.start_date).format('DD MMM YYYY') : ''}</td>
                                                            <td>{res?.end_date ? moment(res?.end_date).format('DD MMM YYYY') : ''}</td>
                                                            <td><div className="btn-group gap-2">
                                                                {/* <Link to="/add-coupon" className="btn btn-white btn-sm"> <i className='fa fa-plus me-1'></i>Add</Link> */}
                                                                <Link to={`/coupon/${res?._id}/edit`} className="btn btn-white btn-sm"> <i className='fa fa-pencil me-1'></i>Edit</Link>
                                                                <button className="btn btn-white btn-sm" type="button" onClick={() => deleteCoupon(res?._id)}> <i className='fa fa-trash me-1'></i>Delete</button>
                                                            </div>
                                                            </td>
                                                        </tr>) : <tr className='text-center'><td colSpan={10}>No Data Found</td></tr>
                                                        }
                                                    </tbody>
                                                </table>}
                                        </div>
                                        {/* pagination  */}
                                        <PaginationLayout
                                            data={couponList.list}
                                            count={couponList.total_count}
                                            limit={Number(Limit)}
                                            page={Number(match?.params.page)}
                                        />
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}
export default CouponListing;