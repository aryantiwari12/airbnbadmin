export interface coupons {
    couponName: string,
    type: string,
    description:string,
    subType: string,
    percentage:string,
    price: number,
    maxDiscount: number,
    startDate: string,
    endDate: string,
    applicable_for: string,
    product_ids: Array<{_id:string,name:string}>,
    language: string
}