import moment from 'moment'
import { Fragment, useContext, useEffect, useState } from 'react'
import { useMatch } from 'react-router-dom'
import { toast } from 'react-toastify'
import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import BreadCrumb from '../../components/common/BreadCrumb'
import Spinner from '../../components/common/spinner'
import { GlobalContext, handleError } from '../../context/Provider'
import henceforthApi from '../../utils/henceforthApi'
import { coupons } from './couponInterface'

const EditCoupon = () => {
    const match = useMatch('/coupon/:id/edit')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Coupons list', url: `/coupons/1`, active: '' },
        { name: 'Edit Coupon', url: ``, active: 'not-allowed' },
    ]
    const { authState, authDispatch, loading, setLoading } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [searchProduct, setSearchProduct] = useState<string>('')
    const [productList, setProductList] = useState<{ _id: string, name: string }[]>([])
    const [couponDetailLoad, setCouponDetailLoad] = useState<boolean>(false)
    const [load, setLoad] = useState<boolean>(false)
    const [coupon, setCoupon] = useState({
        couponName: '',
        type: '',
        description: '',
        subType: '',
        price: 0,
        percentage: '',
        maxDiscount: 0,
        startDate: '',
        endDate: '',
        applicable_for: "ALL",
        product_ids: [],
        language: "ENGLISH"
    } as coupons)

    const [couponNameErr, setCouponNameErr] = useState<string>('')
    const [descriptionErr, setDescriptionErr] = useState<string>('')
    const [typeErr, setTypeNameErr] = useState<string>('')
    const [subTypeErr, setsubTypeNameErr] = useState<string>('')
    const [priceErr, setPriceErr] = useState<string>('')
    const [maxDiscountErr, setMaxDiscountErr] = useState<string>('')
    const [percentageErr, setPercentageErr] = useState<string>('')
    const [startDateErr, setStartDateErr] = useState<string>('')
    const [endDateErr, setEndDateErr] = useState<string>('')
    const handleChange = (e: any) => {
        let name = e.target.name
        let value = e.target.value
        if (name === 'price' && String(value).startsWith('0')) return
        if (name === 'maxDiscount' && String(value).startsWith('0')) return
        if (name === 'percentage' && value.startsWith('0')) return
        if (name === 'price' && isNaN(value) && !value.includes('.') && !String(value).startsWith('0')) return
        if (name === 'maxDiscount' && isNaN(value)) return
        if (name === 'percentage' && isNaN(value)) return
        if (name === 'type' && value) {
            setPriceErr('')
            setMaxDiscountErr('')
            setPercentageErr('')
        }
        if (name === 'startDate' && value === '' || coupon.startDate) {
            setCoupon((coupon: any) => {
                return {
                    ...coupon,
                    endDate: ''
                }
            })
        } 
        setCoupon((coupon: any) => {
            return {
                ...coupon,
                [name]: value
            }
        })
    }

    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (!coupon.couponName.trim() && !coupon.description && !coupon.type.trim() && !coupon.subType.trim() && !coupon.startDate.trim() && !coupon.endDate.trim()) {
            setCouponNameErr('a')
            setTypeNameErr('a')
            setsubTypeNameErr('a')
            // setPriceErr('a')
            // setMaxDiscountErr('a')
            setStartDateErr('a')
            // setPercentageErr('a')
            setEndDateErr('a')
            setDescriptionErr('a')
            return
        }
        if (!coupon.couponName.trim()) return setCouponNameErr('a')
        if (!coupon.description.trim()) return setDescriptionErr('a')
        if (!coupon.type.trim()) return setTypeNameErr('a')
        if (!coupon.subType.trim()) return setsubTypeNameErr('a')
        if (coupon.type === 'PERCENTAGE') {
            if (coupon.maxDiscount === 0 && !coupon.maxDiscount && !coupon.percentage.trim()) {
                setPercentageErr('a')
                setMaxDiscountErr('a')
                return
            }
            if (coupon.maxDiscount === 0) return setMaxDiscountErr('a')
            if (!coupon.maxDiscount) return setMaxDiscountErr('a')
            // if (coupon.maxDiscount >= 100) return setMaxDiscountErr('a')
            if (!coupon.percentage.trim()) return setPercentageErr('a')
            if (Number(coupon.percentage.trim()) === 0) return setPercentageErr('a')
            if (Number(coupon.percentage.trim()) >= 101) return setPercentageErr('a')
        } else if (coupon.type === 'FIXED') {
            if (coupon.price === 0) return setPriceErr('a')
            if (!coupon.price) return setPriceErr('a')
        }
        if (!coupon.startDate) return setStartDateErr('a')
        if (!coupon.endDate) return setEndDateErr('a')
        let ids = coupon.product_ids.map((res) => res._id)
        let items = coupon.type === 'FIXED' ? {
            _id: match?.params.id,
            name: coupon.couponName,
            description: coupon.description,
            type: coupon.type,
            sub_type: coupon.subType,
            start_date: coupon.startDate,
            end_date: coupon.endDate,
            price: coupon.price,
            applicable_for: "ALL",
            product_ids: ids.length ? ids : [],
            language: "ENGLISH"
        } : {
            _id: match?.params.id,
            name: coupon.couponName,
            description: coupon.description,
            type: coupon.type,
            sub_type: coupon.subType,
            start_date: coupon.startDate,
            end_date: coupon.endDate,
            percentage: coupon.percentage,
            max_discount: coupon.maxDiscount,
            applicable_for: ids.length ? "LIMITED" : "ALL",
            product_ids: ids,
            language: "ENGLISH"
        }
        setLoading(true)
        try {
            let apiRes = await henceforthApi.Coupons.editCoupon(items)
            toast.success(apiRes.message)
            window.history.back()
        } catch (err) {
            handleError(err, 'active', authDispatch)

        } finally {
            setLoading(false)
        }
    }
    const productListing = async () => {
        setLoad(true)
        try {
            let res = (await henceforthApi.Product.getProductList(searchProduct, '', '', '')).data.data
            setProductList(res)
        } catch (err) {
            handleError(err, '', authDispatch);
        } finally {
            setLoad(false)
        }
    }
    const couponDetails = async () => {
        setCouponDetailLoad(true)
        try {
            let apiRes = (await henceforthApi.Coupons.getCoupon(match?.params.id)).data
            let res = (await henceforthApi.Product.getProductList('', '', '', '')).data.data
            setCoupon((coupon: any) => {
                return {
                    ...coupon,
                    couponName: apiRes?.name,
                    type: apiRes?.type,
                    description: apiRes?.description,
                    subType: apiRes?.sub_type,
                    price: apiRes?.price,
                    percentage: apiRes?.percentage,
                    maxDiscount: apiRes?.max_discount,
                    startDate: apiRes?.start_date,
                    endDate: apiRes?.end_date,
                    applicable_for: apiRes?.applicable_for,
                    product_ids: res.filter((res: any) => apiRes?.product_ids?.includes(res?._id) && { _id: res._id, name: res.name }),
                    language: "ENGLISH"
                }
            })
        } catch (err: any) {
            console.log(err.response.body.error_description);
            handleError(err, '', authDispatch);
        } finally {
            setCouponDetailLoad(false)
        }
    }
    useEffect(() => { couponDetails() }, [])
    useEffect(() => {
        productListing();
    }, [searchProduct])
    const product_idsHandler = (id: string, name: string, index: number) => {
        if (id && name) {
            let temp2 = coupon.product_ids.some((res) => res._id === id && res.name === name)
            // let temp = coupon.product_ids.filter((res) => res._id !== id && res.name !== name)
            if (temp2) return toast.warn('Already Added')
            setCoupon({
                ...coupon,
                product_ids: [...coupon.product_ids, { _id: id, name: name }]
            })
            setSearchProduct('')
        }
        else {
            coupon.product_ids.splice(index, 1)
            setCoupon((coupon) => { return { ...coupon } })
        }
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            {couponDetailLoad ?
                <div className='data-list-table table-responsive mt-5 text-center'>
                    <Spinner color={"text-success"} />
                </div> :
                <div className='page-spacing'>
                    <section className='change-password'>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-md-12">
                                    <div className="common-card">
                                        <div className="common-card-content">
                                            <div className="form-fields-box">
                                                <label className="mb-1 form-label fw-semibold"><b>Search Product</b> (Search your product and coupon valid for selected product)</label>
                                                <div className="position-relative">
                                                    <input type="search" className="form-control rounded-0 ps-4 " name="search" placeholder="search your product" value={searchProduct} onChange={({ target }: any) => { setLoad(true); setSearchProduct(target.value) }} />
                                                    <span className="search-icon">
                                                        <i className="fa fa-search"></i>
                                                    </span>

                                                    {searchProduct && Array.isArray(productList) && !load && productList.length ? <ul className='mb-0 list-unstyled search-coupon-list'>
                                                        {productList.map((res) => <li key={res._id} onClick={() => product_idsHandler(res._id, res.name, -1)}><p>{res?.name}</p></li>)}
                                                    </ul> : ''}
                                                </div>
                                                {/* coupon-list-box */}
                                                {Array.isArray(coupon.product_ids) && coupon.product_ids.length ? <div className="coupon-list-box mt-3 d-inline-flex gap-3">
                                                    {coupon.product_ids.map((res, index) => <span className='coupon-list-badge' key={res._id} >{res.name} <i className='fa fa-close ms-1' role="button" onClick={() => product_idsHandler('', '', index)}></i></span>)}
                                                </div> : ''}
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div className="row">
                                <div className="col-sm-12">
                                    {/* Title  */}
                                    <div className="common-card">
                                        <div className="common-card-title">
                                            <h5>Edit Coupon</h5>
                                        </div>
                                        <div className="common-card-content">
                                            <div className="table-responsive data-list-table table-responsive mb-3'">
                                                {/* form  */}
                                                <form onSubmit={handleSubmit}>
                                                    {/* table  */}
                                                    <table className="table table table-striped align-middle ">
                                                        <thead>
                                                            <tr>
                                                                <th>
                                                                    Coupon Name
                                                                </th>
                                                                <th>
                                                                    Description
                                                                </th>
                                                                <th>
                                                                    Type
                                                                </th>
                                                                <th>
                                                                    Sub Type
                                                                </th>
                                                                <th>
                                                                    Price(&#8377;)
                                                                </th>
                                                                <th>
                                                                    Max Discount(&#8377;)
                                                                </th>
                                                                <th>
                                                                    Percentage
                                                                </th>
                                                                <th>
                                                                    Start Date
                                                                </th>
                                                                <th>
                                                                    End Date
                                                                </th>
                                                                <th>
                                                                    Actions
                                                                </th>
                                                            </tr>
                                                        </thead>
                                                        <tbody>
                                                            <tr>
                                                                <td className='form-fields-box'>
                                                                    <input type="text" className={`form-control rounded-0 ${couponNameErr ? 'is-invalid' : ''}`} placeholder="Coupon Name" value={coupon.couponName} name='couponName' onChange={(e) => { setCouponNameErr(''); handleChange(e) }} />
                                                                </td>
                                                                <td className='form-fields-box'>
                                                                    <input type="text" className={`form-control rounded-0 ${descriptionErr ? 'is-invalid' : ''}`} placeholder="description" value={coupon.description} name='description' onChange={(e) => { setDescriptionErr(''); handleChange(e) }} />
                                                                </td>
                                                                <td className='form-select-box '>
                                                                    <select className={`form-control rounded-0 ${typeErr ? 'is-invalid' : ''}`} value={coupon.type} name="type" onChange={(e) => { setTypeNameErr(''); handleChange(e) }} >
                                                                        <option value=''>Select Type</option>
                                                                        <option value='FIXED'>Fixed Price</option>
                                                                        <option value='PERCENTAGE'>Percentage</option>

                                                                    </select>
                                                                </td>
                                                                <td className='form-select-box '>
                                                                    <select className={`form-control rounded-0 ${subTypeErr ? 'is-invalid' : ''}`} value={coupon.subType} name='subType' onChange={(e) => { setsubTypeNameErr(''); handleChange(e) }}>
                                                                        <option value=''>Select Sub Type</option>
                                                                        <option value='ONE_TIME'>One time coupon</option>
                                                                    </select>
                                                                </td>
                                                                <td className='form-fields-box'>
                                                                    <input type="text" className={`form-control rounded-0 ${priceErr ? 'is-invalid' : ''}`} placeholder="10" name='price' value={coupon.price === 0 ? '' : coupon.price} onChange={(e) => { setPriceErr(''); handleChange(e) }} disabled={!coupon.type || coupon.type === "PERCENTAGE"} />
                                                                </td>
                                                                <td className='form-fields-box'>
                                                                    <input type="text" className={`form-control rounded-0 ${maxDiscountErr ? 'is-invalid' : ''}`} placeholder="10" name='maxDiscount' value={coupon.maxDiscount === 0 ? '' : coupon.maxDiscount} onChange={(e) => { setMaxDiscountErr(''); handleChange(e) }} disabled={!coupon.type || coupon.type === "FIXED"} />
                                                                </td>
                                                                <td className='form-fields-box'>
                                                                    <input type="text" className={`form-control rounded-0 ${percentageErr ? 'is-invalid' : ''}`} placeholder="10" name='percentage' value={coupon.percentage} maxLength={3} onChange={(e) => { setPercentageErr(''); handleChange(e) }} disabled={!coupon.type || coupon.type === "FIXED"} />
                                                                </td>
                                                                <td className='form-fields-box '>
                                                                    <input type="date" className={`form-control rounded-0 ${startDateErr ? 'is-invalid' : ''}`} name='startDate' min={coupon.startDate} value={coupon.startDate} onChange={(e) => { setStartDateErr(''); handleChange(e) }} />
                                                                </td>
                                                                <td className='form-fields-box '>
                                                                    <input type="date" className={`form-control rounded-0 ${endDateErr ? 'is-invalid' : ''}`} name='endDate' min={moment(coupon.startDate).add(1, 'days').format('YYYY-MM-DD')} value={coupon.endDate} onChange={(e) => { setEndDateErr(''); handleChange(e) }} disabled={!coupon.startDate} />
                                                                </td>
                                                                <td>
                                                                    <button type="submit" className="btn btn-white btn-sm " disabled={loading}>{loading ? <Spinner color='text-success' /> : <><i className="fa fa-save me-2"></i> Save</>}</button>
                                                                </td>
                                                            </tr>

                                                        </tbody>

                                                    </table>
                                                </form>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>
            }
        </Fragment>
    )
}
export default EditCoupon;