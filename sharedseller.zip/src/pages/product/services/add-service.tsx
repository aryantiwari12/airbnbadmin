import '../../../assets/styles/auth.scss'
import '../../../assets/styles/pages.scss';
import {  useMatch } from 'react-router-dom';
import { Fragment, useContext, useState } from 'react';
import { GlobalContext, handleError } from '../../../context/Provider';
import henceforthApi from '../../../utils/henceforthApi';
import Spinner from '../../../components/common/spinner';
import Errormessage from '../../../components/common/errormessage';
import BreadCrumb from '../../../components/common/BreadCrumb';
import Inputs, { SaveCancelButton } from '../../../components/common/Inputs';
import commonArray from '../../../components/common/commonArray';

const AddService = () => {
    const match=useMatch('/product/:product_id/services/add')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' }, 
        { name: 'Product List', url: `/products/1`, active: '' },
        { name: 'Product detail', url: `/product/${match?.params.product_id}`, active: '' },
        { name: 'Add Service', url: ``, active: 'not-allowed' }
    ]
    const {authState,loading,setLoading,toastMessage,authDispatch}=useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [addServices, setAddServices] = useState<string>("")
    const [servicesErr,setServicesErr]=useState<string>('')
    const handleSubmit = async (e:any) => {
        e.preventDefault()
        if(!addServices) return setServicesErr("Service is required")
        if(!addServices.trim()) return setServicesErr("Please write something in service")
        let items = {
            product_id:match?.params.product_id ,
            services: [
                addServices
            ],
            language: "ENGLISH"
        }
        setLoading(true)
        try {
          let addServiceResp= await henceforthApi.Product.addProductDetailsDynamically(commonArray.productOtherDetails[4],items)
          toastMessage(addServiceResp.message)
          window.history.back()
        setLoading(false)
        } catch (err) {
            handleError(err,'active',authDispatch);
            setLoading(false)
        }
    }
    const handleChange=(e:any)=>{
        setAddServices(e.target.value)
        setServicesErr('')
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-9 col-md-6 col-lg-5 col-xl-4 col-xxl-3">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Add Service</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={handleSubmit}>
                                            {/* Services */}
                                            <Inputs.Input type="text" error={servicesErr} value={addServices} placeholder="Enter your service" handleChange={handleChange} />
                                            {/* Submit Button  */}
                                            <SaveCancelButton loading={loading} color="text-white" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}

export default AddService;