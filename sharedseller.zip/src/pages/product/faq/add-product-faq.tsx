import '../../../assets/styles/pages.scss'
import TextEditor from '../../../components/text-editor';
import { useMatch } from 'react-router-dom'
import { Fragment, useContext, useState } from 'react';
import henceforthApi from '../../../utils/henceforthApi';
import { GlobalContext, handleError } from '../../../context/Provider';
import Spinner from '../../../components/common/spinner';
import Errormessage from '../../../components/common/errormessage';
import Svg from '../../../components/common/error-svg';
import BreadCrumb from '../../../components/common/BreadCrumb';
import { faqType } from '../productInterface';
import Inputs, { SaveCancelButton } from '../../../components/common/Inputs';
import commonArray from '../../../components/common/commonArray';

const AddProductFaq = () => {
    const match = useMatch('/product/:product_id/faq/add')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Product List', url: `/products/1`, active: '' },
        { name: 'Product detail', url: `/product/${match?.params.product_id}`, active: '' },
        { name: 'Add Product FAQ', url: ``, active: 'not-allowed' }
    ]
    const { authState, loading, setLoading, authDispatch, toastMessage } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [answerErr, setAnswerErr] = useState<string>('')
    const [questionErr, setQuestionErr] = useState<string>('')
    const [addFaq, setAddFaq] = useState<any>({
        product_id: match?.params?.product_id,
        question: "",
        answer: ""
    } as faqType)
    const handleChange = (e: any) => {
        let name = e?.target?.name??'answer';
        let value = e?.target?.value??e;
        if (name === "question") setQuestionErr('')
        if (name === "answer") setAnswerErr('')
        setAddFaq({
            ...addFaq,
            [name]: value,
        });
    };

    const handleSubmit = async (e: any) => {
        e.preventDefault()
        if (!addFaq.answer && !addFaq.question) {
            setQuestionErr("Question is required")
            setAnswerErr("Answer is required")
            return
        }
        if (addFaq.answer.trim() === '<p><br></p>' && !addFaq.question) {
            setQuestionErr("Question is required")
            setAnswerErr("Answer is required")
            return
        }
        if (!addFaq.question) return setQuestionErr("Question is required")
        if (!addFaq.question.trim()) return setQuestionErr("Please Write Something in question")
        if (addFaq.answer.trim() === '<p><br></p>') return setAnswerErr("Answer is required")
        if ((addFaq.answer.trim().length < 7) || addFaq.answer.trim() === '<p></p>') return setAnswerErr("Answer is required")
        if (!addFaq.answer.trim()) return setAnswerErr("Please Write Something in answer")
        setLoading(true)
        try {
            let res = await henceforthApi.Product.addProductDetailsDynamically(commonArray.productOtherDetails[3],addFaq)
            toastMessage(res.message)
            window.history.back()
        } catch (err) {
            handleError(err, 'active', authDispatch);
        } finally {
            setLoading(false)
        }
    }
    return (
        <Fragment>
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing'>
                <section className='product-detail'>
                    <div className="container-fluid">
                        <div className="row">
                            <div className="col-sm-10 col-md-7 col-lg-6 col-xl-5 col-xxl-5">
                                {/* Title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Add Product FAQ</h5>
                                    </div>
                                    {/* Profile  */}
                                    <div className="common-card-content">
                                        <form onSubmit={handleSubmit}>
                                            {/* Question  */}
                                            <Inputs.Input type="text" label="Question" error={questionErr} value={addFaq.question} placeholder="Add your Question here" name="question" handleChange={handleChange} />
                                            {/* Answer  */}
                                            <div className='text-editor mb-4'>
                                                <label className="mb-2 fw-bolder">Answer</label>
                                                <div className={`quill ${answerErr ? 'border border-danger mb-2 position-relative' : ''}`}>
                                                    <TextEditor value={addFaq.answer} onChange={handleChange} />
                                                    {answerErr ? <span className='svg-question'>
                                                        <Svg /></span> : ''}
                                                </div>
                                                <Errormessage phone={answerErr} error={answerErr} />
                                                {/* Button  */}
                                                <SaveCancelButton loading={loading} color="text-white" />
                                            </div>
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}
export default AddProductFaq;