import { Fragment, useContext, useState } from 'react';
import {  useLocation, useMatch } from 'react-router-dom';
import BreadCrumb from '../../../components/common/BreadCrumb';
import commonArray from '../../../components/common/commonArray';
import Errormessage from '../../../components/common/errormessage';
import Inputs, { SaveCancelButton } from '../../../components/common/Inputs';
import Spinner from '../../../components/common/spinner';
import { GlobalContext, handleError } from '../../../context/Provider';
import henceforthApi from '../../../utils/henceforthApi';

const EditHighlight = () => {
    const location = useLocation()
    const match = useMatch("product/:id/highlight/:highlight_id/edit")
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' }, 
        { name: 'Product List', url: `/products/1`, active: '' },
        { name: 'Product detail', url: `/product/${match?.params.id}`, active: '' },
        { name: 'Edit Highlight', url: ``, active: 'not-allowed' }
    ]
    const { authState,toastMessage,authDispatch } = useContext(GlobalContext);
    henceforthApi.setToken(authState.access_token);
    const newParam = new URLSearchParams(location.search);
    const [highlights, setHighlights] = useState(newParam.get("content") as string)
    const [loading, setLoading] = useState<boolean>(false)
    const [highlightsErr, setHighlightsErr] = useState<string>("")

    const edit = async () => {
        const items = {
            _id: match?.params.highlight_id,
            product_id: match?.params.id,
            content: highlights,
            language: "ENGLISH"
        }
        if (!highlights) return setHighlightsErr("Highlight is required")
        if (!highlights.trim()) return setHighlightsErr("Please Write Something in Highlights")
        setLoading(true)
        try {
            const apiRes = await henceforthApi.Product.editProductDetailsDynamically(commonArray.productOtherDetails[0],items)
            toastMessage(apiRes.message)
            window.history.back()
        } catch (error) {
            handleError(error,'active',authDispatch);
        } finally {
            setLoading(false)
        }

    }
    const handleChange=(e:any)=>{
        setHighlights(e.target.value)
        setHighlightsErr('')
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row justify-content-center">
                            <div className="col-sm-10 col-md-7 col-lg-6 col-xl-5 col-xxl-3">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Edit Highlight</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={(e) => { e.preventDefault(); edit() }}>
                                            {/* Highlight */}
                                            <Inputs.Input type="text" error={highlightsErr} value={highlights} placeholder="Enter your highlight" handleChange={handleChange} />
                                            {/* Submit Button  */}
                                            <SaveCancelButton loading={loading} color="text-white" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}

export default EditHighlight;