import { useMatch } from 'react-router-dom';
import { Fragment, useContext, useState } from 'react';
import henceforthApi from '../../../utils/henceforthApi';
import { GlobalContext, handleError } from '../../../context/Provider';
import Spinner from '../../../components/common/spinner';
import Errormessage from '../../../components/common/errormessage';
import BreadCrumb from '../../../components/common/BreadCrumb';
import Inputs, { SaveCancelButton } from '../../../components/common/Inputs';
import commonArray from '../../../components/common/commonArray';

const AddHighlight = () => {
    const match = useMatch("product/:product_id/highlight/add")
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' }, 
        { name: 'Product List', url: `/products/1`, active: '' },
        { name: 'Product detail', url: `/product/${match?.params.product_id}`, active: '' },
        { name: 'Add Highlight', url: ``, active: 'not-allowed' }
    ]
    const { authState,loading,setLoading,toastMessage,authDispatch } = useContext(GlobalContext);
    henceforthApi.setToken(authState.access_token);
    const [highlights, setHighlights] = useState<string>("")
    const [highlightsErr, setHighlightsErr] = useState<string>("")


    const add = async () => {
        const items = {
            product_id: match?.params.product_id,
            highlights: [
                highlights
            ],
            language: "ENGLISH"
        }
        if (!highlights) return setHighlightsErr("Highlight is required")
        if (!highlights.trim()) return setHighlightsErr("Please Write Something in Highlights")
        setLoading(true)
        try {
            const apiRes = await henceforthApi.Product.addProductDetailsDynamically(commonArray.productOtherDetails[0],items)
            toastMessage(apiRes.message)
            window.history.back()
        } catch (error) {
            handleError(error,'active',authDispatch);
        } finally {
            setLoading(false)
        }
    }
    const handleChange=(e:any)=>{
        setHighlights(e.target.value)
        setHighlightsErr('')
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing'>
                <section className='edit-profile'>
                    <div className="container-fluid">
                        <div className="row justify-content-center">
                            <div className="col-sm-10 col-md-7 col-lg-6 col-xl-5 col-xxl-3">
                                {/* title  */}
                                <div className="common-card">
                                    <div className="common-card-title">
                                        <h5>Add Highlight</h5>
                                    </div>
                                    {/* form  */}
                                    <div className="common-card-content">
                                        <form onSubmit={(e) => { e.preventDefault(); add() }}>
                                            {/* Highlight */}
                                            <Inputs.Input type="text" error={highlightsErr} value={highlights} placeholder="Enter your highlight" handleChange={handleChange} />
                                            {/* Submit Button  */}
                                            <SaveCancelButton loading={loading} color="text-white" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}

export default AddHighlight;