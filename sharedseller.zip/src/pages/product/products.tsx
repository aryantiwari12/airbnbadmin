import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import laptop from '../../assets/images/pages/laptop.jpg'
import { Link, useLocation, useMatch } from 'react-router-dom'
import { Fragment, useContext, useEffect, useMemo, useState } from 'react'
import DownloadFileModal from '../../components/common/download-file-modal'
import { GlobalContext, handleError } from '../../context/Provider'
import henceforthApi from '../../utils/henceforthApi'
import PaginationLayout from '../../components/common/PaginationLayout'
import Spinner from '../../components/common/spinner'
import moment from 'moment'
import BreadCrumb from '../../components/common/BreadCrumb'
import { numberWithCommas } from '../../utils/validations'
import { ProductList } from './productInterface'
import { toast } from 'react-toastify'
import AllFilter from '../../components/common/AllFilter'
import COPY from "../../../src/assets/images/copy.png"

const Products = () => {
    const match: any = useMatch('/products/:page')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Product List', url: ``, active: 'not-allowed' }
    ]
    let Limit = 10;
    const location = useLocation();
    const newParam = new URLSearchParams(location.search);
    const { authState, loading, setLoading, authDispatch } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [productList, setProductList] = useState({
        totalCount: 0,
        listing: [],
    } as ProductList)
    const exportData = async (startDate: number, endDate: number) => {
        try {
            const apiRes = await henceforthApi.Product.export(startDate, endDate)
            const data = apiRes.data.data
            // console.log('data', data);
            const rows = [
                [
                    "Sr.",
                    "Product Id",
                    "Category Level 1",
                    "Category level 2",
                    "Brand",
                    "Product Name",
                    "Product Price",
                    "Quantity",
                ],
            ];

            if (Array.isArray(data)) {
                data.map((res: any, index: any) => {
                    return rows.push([
                        index,
                        res?.prodct_id,
                        res?.category_id?.name,
                        res?.subcategory_id?.name,
                        res?.brand_id?.name,
                        res?.name,
                        res?.price,
                        res?.quantity,
                    ])
                })
            }
            console.log(rows);
            let csvContent =
                "data:text/csv;charset=utf-8," +
                rows.map((e) => e.join(",")).join("\n");
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `user_${moment().valueOf()}.csv`);
            document.body.appendChild(link); // Required for FF
            link.click(); // This will download the data file named "my_data.csv".
            let closeModal = document.getElementById("closeModal");
            if (closeModal) {
                closeModal.click();
            }
        } catch (error) {
            handleError(error, 'active', authDispatch);
        }

    }
    const copyText = (id: string) => {
        if (id) {
            navigator?.clipboard?.writeText(id)
            toast.success(`ProductId copy successfull`)
        }
    }
    const productListing = async () => {

        setLoading(true)
        try {
            let res = (await henceforthApi.Product.getProductList('', Number(match?.params.page) - 1, Limit, newParam.toString())).data
            setProductList({
                ...productList,
                totalCount: res.total_count,
                listing: res.data,
            })

        } catch (err: any) {
            console.log("err", err.response.body.error_description);
            if (newParam.has('product_id')) {
                toast.warn('Please Search Proper Id')
                setProductList({
                    ...productList,
                    listing: [],
                })
            }
            handleError(err, '', authDispatch);
        } finally {
            setLoading(false)
        }
    }


    useEffect(() => {
        productListing();

    }, [match?.params.page, newParam.get("search"), newParam.get("product_id"), newParam.get("min_price"), newParam.get("max_price")])
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* Page  */}
            <div className='page-spacing'>
                <section className='products'>
                    <div className='product-detail-box'>
                        <AllFilter />
                        <div className="common-card">
                            <div className="common-card-title d-flex justify-content-between align-items-center gap-2 flex-column flex-sm-row">
                                <h5>Product Listing Detail</h5>
                                <div>
                                    <Link className="btn btn-white btn-sm" to="/product/add"> <i className="fa fa-plus me-1"></i>Add</Link>
                                </div>
                            </div>
                            <div className="common-card-content">
                                {/* table */}
                                <div className='data-list-table table-responsive mb-3 text-center'>
                                    {loading ? <Spinner color={"text-success"} />
                                        :
                                        <table className="table table-striped align-middle text-center">
                                            <thead className=''>
                                                <tr>
                                                    <th>Sr.No.</th>
                                                    <th>Product Id</th>
                                                    <th>Category Level 1</th>
                                                    <th>Category level 2</th>
                                                    <th>Brand</th>
                                                    <th>Product</th>
                                                    <th>Product Price</th>
                                                    <th>Quantity</th>
                                                    <th>Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>

                                                {Array.isArray(productList.listing) && productList.listing.length ? productList.listing.map((res, index: number) =>
                                                    <tr key={res?._id}>
                                                        <td> {match?.params.page === "0"
                                                            ? index + 1
                                                            : (Number(match?.params.page) - 1) * Limit + (index + 1)}</td>
                                                        <td>{res?.prodct_id ? res?.prodct_id : 'Not Avaialable'} <img src={COPY}  style={{width:15}} onClick={()=>copyText(res.prodct_id)} role="button" data-toggle="tooltip" title={`${res.prodct_id}`} /></td>
                                                        <td>{res?.category_id ? res?.category_id?.name : "Not Avaialable"}</td>
                                                        <td>{res?.subcategory_id
                                                            ? res?.subcategory_id
                                                                ?.name : "Not Avaialable"}</td>
                                                        <td>{res?.brand_id?.name ? res?.brand_id?.name : 'HP'}</td>
                                                        <td className='product-image-table'>
                                                            <img className='me-2' src={Array.isArray(res?.images) && res?.images?.length ? `${henceforthApi.API_FILE_ROOT_SMALL}${res?.images[0]}` : laptop} alt={res.images[0]} />
                                                            {res?.name?.length > 18 ? <Fragment>{res?.name?.slice(0, 18)}...</Fragment> : res?.name ? res?.name : "Not Available"}</td>
                                                        <td><b>&#36;</b> {res?.price ? numberWithCommas(res?.price) : 'Not Available'}</td>
                                                        <td>{res?.quantity !== 0 ? res?.quantity : 'Out of Stock'}</td>
                                                        <td>
                                                            <div className="btn-group gap-2">
                                                                <Link className="btn btn-white btn-sm" to={`/product/${res?._id}`}> <i className="fa fa-eye me-1"></i>View</Link>
                                                                <Link className="btn btn-white btn-sm" to={`/product/${res?._id}/edit`}> <i className="fa fa-pencil me-1"></i>Edit</Link>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                                    : <tr className='text-center'><td colSpan={9}>No Data Found</td></tr>}



                                            </tbody>
                                        </table>}
                                </div>
                                {/* pagination  */}
                                <div className='dashboad-pagination-box'>
                                    <PaginationLayout
                                        data={productList.listing}
                                        count={productList.totalCount}
                                        limit={Number(Limit)}
                                        page={Number(match?.params.page)}
                                    />
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <DownloadFileModal exportData={useMemo(() => exportData, [])} />
        </Fragment>
    )
}
export default Products;