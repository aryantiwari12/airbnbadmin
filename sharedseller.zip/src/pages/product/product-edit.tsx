import imageUpload from '../../assets/icons/plus.png';
import '../../assets/styles/pages.scss'
import { useMatch } from 'react-router-dom'
import { Fragment, useContext, useEffect, useState } from 'react';
import henceforthApi from '../../utils/henceforthApi';
import { GlobalContext, handleError } from '../../context/Provider';
import Spinner from '../../components/common/spinner';
import { documentId, formValidate, NumberValidation } from '../../utils/validations';
import Errormessage from '../../components/common/errormessage';
import BreadCrumb from '../../components/common/BreadCrumb';
import { editBrandListing, editProductData, subLists } from './productInterface';
import Input, { SaveCancelButton } from '../../components/common/Inputs';
import Select from '../../components/common/Select';
import commonArray from '../../components/common/commonArray';
import Textarea from '../../components/common/Textarea';
import Inputs from '../../components/common/Inputs';
import { toast } from 'react-toastify';


const EditProduct = () => {
    const match = useMatch('/product/:id/edit')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Product List', url: `/products/1`, active: '' },
        { name: 'Product Detail', url: `/product/${match?.params.id}`, active: '' },
        { name: 'Edit Product', url: ``, active: 'not-allowed' }
    ]
    const { authState, authDispatch, loading, setLoading, toastMessage } = useContext(GlobalContext);
    henceforthApi.setToken(authState.access_token);
    const [nameErr, setNameErr] = useState<string>("")
    const [brandErr, setBrandErr] = useState<string>("")
    const [priceErr, setPriceErr] = useState<string>("")
    const [taxErr, setTaxErr] = useState<string>("")
    const [categoryErr, setCategoryErr] = useState<string>("")
    const [quantityErr, setQuantityErr] = useState<string>("")
    const [pageLoading, setPageLoading] = useState<boolean>(false)
    const [descriptionErr, setDescriptionErr] = useState<string>("")
    const [subCategoryErr, setSubcategoryErr] = useState<string>("")
    const [selectedFileErr, setSelectedFileErr] = useState<string>('')
    const [subCategory, setSubCategory] = useState<Array<subLists>>([])
    const [subSubCategory, setSubSubCategory] = useState<Array<subLists>>([])
    const [selectedFile, setSelectedFile] = useState<Array<Blob | MediaSource>>([])
    const [brandDetails, setBrandDetails] = useState({
        brand: [],
        category: [],
    } as editBrandListing)
    // parcel: [],
    const [editProduct, setEditProduct] = useState({
        name: '',
        description: '',
        brand_id: '',
        category_id: '',
        subcategory_id: '',
        sub_subcategory_id: '',
        images: [],
        tax_percentage: '',
        quantity: '',
        price: '',
        discount_percantage: '',
        sold: false,
        is_blocked: false,
        is_deleted: false,
        language: ''
    } as editProductData);
    const brandListing = async () => {
        try {
            let apiBrandRes = (await henceforthApi.categorylisting.Brandlisting()).data.data;
            let apiCategoryRes = (await henceforthApi.categorylisting.categorylisting()).data.data;
            setBrandDetails({
                ...brandDetails,
                brand: apiBrandRes,
                category: apiCategoryRes,
            });
        } catch (err) {
            handleError(err, '', authDispatch);
            console.log(err);
        }
    };
    useEffect(() => {
        brandListing();
    }, []);
    const subListing = async () => {
        try {
            let apiSubCategoryRes = (await henceforthApi.categorylisting.subCategorylisting(editProduct.category_id
            )).data.data;
            setSubCategory(apiSubCategoryRes)
        } catch (err) {
            handleError(err, '', authDispatch);
            console.log(err);

        }
    }
    const sub_subListing = async () => {
        let apiSubSubCategoryRes = (await henceforthApi.categorylisting.subSubCategorylisting(editProduct.subcategory_id)).data.data;

        setSubSubCategory(apiSubSubCategoryRes)
    }
    useEffect(() => {
        if ((editProduct.category_id ?? '') !== "") {
            subListing()
        }
    }, [editProduct.category_id])
    useEffect(() => {
        if ((editProduct.subcategory_id ?? '') !== "") {
            sub_subListing()
        }
    }, [editProduct.subcategory_id])
    const handleFile = async (e: any) => {
        let files = e.target.files as Array<Blob | MediaSource>
        setSelectedFile([...selectedFile, ...files])
        e.target.value = ""
    };
    const clearInputErr = (name: string) => {
        if (name === 'name') setNameErr('')
        if (name === 'description') setDescriptionErr('')
        if (name === 'brand_id') setBrandErr('')
        if (name === 'category_id') setCategoryErr('')
        // if (name === 'category_id'&& categoryErr) setEditProduct((editProduct) => {return {...editProduct,subcategory_id: '',}});
        if (name === 'subcategory_id') setSubcategoryErr('')
        // if (name === 'subcategory_id' && subCategoryErr) setEditProduct((editProduct) => {return {...editProduct,subcategory_id: '',}});
        // if (name === 'subcategory_id') setCategoryErr('')
        if (name === 'tax_percentage') setTaxErr('')
        if (name === 'quantity') setQuantityErr('')
        if (name === 'price') setPriceErr('')
    }
    const handleChange = (e: any) => {
        let name = e.target.name;
        let value = e.target.value;
        clearInputErr(name)
        let res = formValidate(name, value)
        if (res === false) return
        if (name === 'category_id' && !value) setEditProduct((editProduct) => { return { ...editProduct, subcategory_id: '', sub_subcategory_id: '' } });
        if (name === 'subcategory_id' && !value) setEditProduct((editProduct) => { return { ...editProduct, sub_subcategory_id: '', } });
        setEditProduct((editProduct) => {
            return {
                ...editProduct,
                [name]: value,
            }
        });
    };
    const uploadImages = async () => {
        const images = [] as Array<string>
        await Promise.all(selectedFile.map(async (res) => {
            try {
                const apiRes = await henceforthApi.Common.do_spaces_file_upload(`file`, res)
                const data = apiRes.data
                images.push(data.file_name)
            } catch (err) {
                handleError(err, 'active', authDispatch);
                console.log(err);
            }
        }
        ))
        return images
    }
    const handleSubmit = async (e: any) => {
        e.preventDefault();
        if (!selectedFile.length && !editProduct.name && !editProduct.description && !editProduct.tax_percentage && !editProduct.brand_id && !editProduct.category_id && !editProduct.subcategory_id && !editProduct.quantity && !editProduct.price) {
            setSelectedFileErr('Image is required')
            setNameErr('Name is required')
            setDescriptionErr('Description is required')
            setBrandErr('Brand is required')
            setTaxErr('Tax is required')
            setCategoryErr('Category is required')
            setSubcategoryErr('Subcategory is required')
            setQuantityErr('Quantity is required')
            setPriceErr('Price is required')
            return
        }
        if (selectedFile.length === 0 && editProduct.images.length === 0) { setSelectedFileErr("Please select images"); documentId('images'); return }
        if (!editProduct.name.trim()) { documentId('productName'); setNameErr("Please provide name"); return }
        if (!editProduct.description.trim()) { documentId('description'); setDescriptionErr("Please provide description"); return }
        if (!editProduct.price) { documentId('price'); setPriceErr("Please add price"); return }
        if (!Number(editProduct.price)) { documentId('price'); setPriceErr("Only use number in price"); return }
        if (!editProduct.tax_percentage) { documentId('tax_percentage'); setTaxErr("Please add tax"); return }
        if (!Number(editProduct.tax_percentage)) { documentId('tax_percentage'); setTaxErr("Only use number in tax"); return }
        if (!editProduct.quantity) { documentId('quantity'); setQuantityErr("Please add quantity"); return }
        if (!Number(editProduct.quantity)) { documentId('quantity'); setQuantityErr("Only use number in quantity"); return }
        if (!editProduct.brand_id.trim()) { documentId('brand_id'); setBrandErr("Please select brand"); return }
        if (!editProduct.category_id.trim()) { documentId('category_id'); setCategoryErr("Please select category"); return }
        if (!editProduct.subcategory_id.trim()) { documentId('subcategory_id'); setSubcategoryErr("Please select subcategory"); return }
        setLoading(true)
        const images = await uploadImages()
        // product_type:'WAERABLE_PRODUCT',
        // product_type:'ELECTRONICS',
        const items = {
            _id: match?.params.id,
            name: editProduct.name,
            description: editProduct.description,
            brand_id: editProduct.brand_id,
            category_id: editProduct.category_id,
            subcategory_id: editProduct.subcategory_id,
            sub_subcategory_id: editProduct.sub_subcategory_id,
            images: [...images, ...editProduct.images],
            tax_percentage: Number(editProduct.tax_percentage),
            quantity: Number(editProduct.quantity),
            price: Number(editProduct.price),
            discount_percantage: Number(editProduct.discount_percantage),
            language: "ENGLISH"
        }
        try {
            let res = await henceforthApi.Product.editProduct(items)
            // console.log(res);
            toastMessage(res.message)
            setEditProduct({
                name: "",
                description: "",
                brand_id: "",
                category_id: "",
                subcategory_id: "",
                sub_subcategory_id: '',
                images: [],
                quantity: '',
                price: "",
                discount_percantage: '',
                tax_percentage: '',
                sold: false,
                is_blocked: false,
                is_deleted: false,
                language: "ENGLISH"
            });
            // toastMessage(res.message)
            window.history.back();
        } catch (err: any) {
            // console.log(err);
            handleError(err, 'active', authDispatch);
        } finally {
            setLoading(false)
        }
    };

    const productDetails = async () => {
        setPageLoading(true)
        try {
            let productRes = (await henceforthApi.Product.getProductDetails(match?.params.id)).data
            setEditProduct({
                ...editProduct,
                name: productRes?.name,
                description: productRes?.description,
                brand_id: productRes?.brand_id?._id,
                category_id: productRes?.category_id?._id,
                subcategory_id: productRes?.subcategory_id?._id,
                sub_subcategory_id: productRes?.sub_subcategory_id?._id,
                tax_percentage: productRes?.tax_percentage,
                images: productRes?.images,
                quantity: productRes?.quantity,
                price: productRes?.price,
                discount_percantage: productRes?.discount_percantage,
            })
        } catch (err: any) {
            handleError(err, '', authDispatch);
            console.log(err.response);
        } finally {
            setPageLoading(false)
        }
    }
    useEffect(() => {
        productDetails()
    }, [])
    const imageRemove = (del: string, id: number) => {
        if (del) {
            editProduct.images.splice(id, 1)
            setEditProduct({
                ...editProduct,
            })
        } else {
            selectedFile.splice(id, 1)
            setSelectedFile([
                ...selectedFile,
            ])
        }
    }
    return (
        <Fragment>
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            {pageLoading ?
                <div className='vh-100 d-flex justify-content-center py-5'>
                    <Spinner color={"text-success"} />
                </div>
                : <div className='page-spacing'>
                    <section className='product-detail'>
                        <div className="container-fluid">
                            <div className="row">
                                <div className="col-sm-12 col-md-8 col-lg-7 col-xl-6 col-xxl-5">
                                    {/* Title  */}
                                    <div className="common-card">
                                        <div className="common-card-title">
                                            <h5>Edit Product</h5>
                                        </div>
                                        {/* Profile  */}
                                        <div className="common-card-content">
                                            <form onSubmit={handleSubmit}>

                                                <div className="upload-fields-box mb-3">
                                                    <label htmlFor="" className='fw-bolder mb-2'>Product Image</label>
                                                    {/* Upload image */}

                                                    <div className="product-edit-image d-flex gap-2 gap-md-4 gap-lg-5 flex-column flex-sm-row">
                                                        <div className="product-edit-upload">
                                                            <div className='upload-fields-box mb-3'>
                                                                <div className='profile-edit-image mb-2 mx-0'>
                                                                    <div className='profile-edit-upload'>
                                                                        <input
                                                                            id="images"
                                                                            onChange={(e) => { setSelectedFileErr(''); handleFile(e) }}
                                                                            type="file"
                                                                            className={`form-control ${selectedFileErr ? 'is-invalid' : ''}`}
                                                                            accept='image/png,image/jpeg'
                                                                            multiple
                                                                        />
                                                                    </div>
                                                                    <img src={imageUpload} alt="img" className={`rounded-circle ${selectedFileErr ? 'border border-danger' : ''}`} />
                                                                </div>
                                                                <Errormessage phone={selectedFileErr} error={selectedFileErr} />
                                                            </div>
                                                        </div>
                                                        <div className='product-images-preview d-inline-flex gap-sm-4 gap-md-4 gap-lg-5 gap-3 flex-wrap flex-column flex-sm-row'>
                                                            {editProduct.images && editProduct.images.map((res, index: number) => {
                                                                return (
                                                                    <div key={index} className='preview-image-box position-relative'>
                                                                        <img
                                                                            className="Product-Images border border-dark"
                                                                            src={`${henceforthApi.API_FILE_ROOT_MEDIUM}${res}`} alt={res} />
                                                                        {editProduct.images[0] !== "" && <span key={Math.random()} className='preview-image-close ' onClick={() => imageRemove("del", index)}><i className='fa fa-close text-dark' style={{ cursor: 'pointer' }}></i> </span>}
                                                                    </div>
                                                                )
                                                            })}
                                                            {Array.isArray(selectedFile) ? selectedFile.map((res, index: number) => {

                                                                return (
                                                                    <div key={index} className='preview-image-box position-relative'><img
                                                                        className="Product-Images border border-dark"
                                                                        src={URL.createObjectURL(res)} alt="img" />
                                                                        {<span key={Math.random()} className='preview-image-close ' onClick={() => imageRemove("", index)}><i className='fa fa-close text-dark' style={{ cursor: 'pointer' }}></i> </span>}
                                                                    </div>
                                                                )
                                                            }) : ''}
                                                        </div>
                                                    </div>
                                                </div>
                                                <p><small><strong>Note:-</strong> Please upload only .jpg and .png format only.</small></p>
                                                <div className='divider my-3'></div>
                                                {/* Product Name  */}
                                                <Inputs.Input type='text' id="productName" error={nameErr} label='Product Name' name='name' placeholder="Product Name" value={editProduct.name} handleChange={handleChange} />
                                                {/* Product Description  */}
                                                <Textarea error={descriptionErr} id="description" col={30} row={5} label='Product Description' name='description' placeholder="Product Description" value={editProduct.description} handleChange={handleChange} />
                                                {/* Product Price  */}
                                                <Inputs.Input type='text' id="price" error={priceErr} label='Product Price (&#36;)' name='price' placeholder="Price" value={editProduct.price} handleChange={handleChange} />
                                                {/* Product tax  */}
                                                <Inputs.Input type='text' error={taxErr} label='Tax Percentage (%)' name='tax_percentage' placeholder="tax percentage" value={editProduct.tax_percentage} handleChange={handleChange} />
                                                {/* Quantity */}
                                                <Inputs.Input type='number' id="quantity" error={quantityErr} label='Quantity' name='quantity' placeholder="Quantity" value={editProduct.quantity} handleChange={handleChange} />
                                                {/* Brand  */}
                                                <Select Array={brandDetails.brand} id="brand_id" error={brandErr} label='Brand' firstSelect='Brand' name='brand_id' value={editProduct.brand_id} handleChange={handleChange} />
                                                {/* Category-1  */}
                                                <Select Array={brandDetails.category} id="category_id" error={categoryErr} label='Category Level 1' firstSelect='Category' name='category_id' value={editProduct.category_id} handleChange={handleChange} />
                                                {/* Category-2  */}
                                                <Select Array={subCategory} disabled={!editProduct.category_id} error={subCategoryErr} label='Category Level 2' firstSelect='SubCategory' name='subcategory_id' value={editProduct.subcategory_id} handleChange={handleChange} />
                                                {/* Category-3  */}
                                                <Select Array={subSubCategory} disabled={!editProduct.subcategory_id} label='Category Level 3' firstSelect='Sub_SubCategory' name='sub_subcategory_id' value={editProduct.sub_subcategory_id} handleChange={handleChange} />
                                                {/* Discount  */}
                                                <Inputs.Input type='number' label='Discount' name='discount_percantage' placeholder="Enter your discount" value={editProduct.discount_percantage} handleChange={handleChange} />
                                                {/* <Select Array={commonArray?.discount} label='Discount' firstSelect='Discount' name='discount_percantage' value={editProduct.discount_percantage} handleChange={handleChange} /> */}
                                                <div className="divider my-3"></div>
                                                {/* Buttons  */}
                                                <SaveCancelButton loading={loading} color="text-white" onClick={handleSubmit} />
                                            </form>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </section>
                </div>}
        </Fragment>
    )
}
export default EditProduct;