export interface ProductList {
    totalCount: number,
    listing: Array<innerList>,
}
export interface innerCat {
    name: string
}
export interface innerList {
    _id: string,
    category_id: innerCat,
    subcategory_id: innerCat,
    brand_id: innerCat,
    name: string,
    prodct_id:string,
    discount_price: number,
    price: number,
    images: Array<string>,
    quantity: number,
}
export interface subLists {
    _id: string,
    name: string
}
export interface MultipleSelect {
    key: string,
    value: string
}
export interface dataHolder {
    name: string,
    description: string,
    brand_id: string,
    category_id: string,
    subcategory_id: string,
    sub_subcategory_id: string,
    tax_percentage: string,
    quantity: string,
    price: string,
    discount_percantage: string,
    language: string
}
// parcel_id: string,
export interface editProductData {
    name: string,
    description: string,
    brand_id: string,
    category_id: string,
    subcategory_id: string,
    sub_subcategory_id: string,
    images: Array<string>,
    tax_percentage: string,
    quantity: string,
    price: string,
    discount_percantage: string,
    sold: false,
    is_blocked: false,
    is_deleted: false,
    language: string
}
// parcel: Array<subLists>,
export interface brandListing {
    brand: Array<subLists>,
    category: Array<subLists>,
    subcategory: Array<subLists>,
    subSubcategory: Array<subLists>,
}
// parcel: Array<subLists>,
export interface editBrandListing {
    brand: Array<subLists>,
    category: Array<subLists>,
}
export interface user_id {
    profile_pic: string
}
export interface innerRating {
    ratings: number,
    user_id: {
        name: string,
        profile_pic: string
    },
    created_at: string,
    title: string,
    description: string
}
export interface stateType {
    _id: string,
    name: string,
    description: string,
    product_type: string,
    added_by: subLists,
    category_id: subLists,
    subcategory_id: subLists,
    sub_subcategory_id: subLists,
    brand_id: subLists,
    images: Array<string>,
    quantity: string,
    price: number,
    discount_percantage: string,
    is_delivery_available:boolean,
    tax_percentage: number,
    discount: string,
    discount_price: number,
    total_reviews: string,
    prodct_id:string,
    total_ratings: string,
    ratings: Array<innerRating>,
}

export interface faqType {
    product_id: string,
    question: string,
    answer: string
}
export interface editFaqType {
    product_id: string,
    question: string,
    answer: string
    language: string,
}
export interface deliveryType {
    deliveryTime: string,
    radius: string,
    location: string
    lat: string,
    lng: string,
}