import { Fragment, useContext, useEffect, useState } from "react";
import { useMatch } from "react-router-dom";
import BreadCrumb from "../../components/common/BreadCrumb";
import CustomerInvoicePdf from "../../components/customer-invoice/customer-invoice-pdf";
import { GlobalContext, handleError } from "../../context/Provider";
import henceforthApi from "../../utils/henceforthApi";
import { orderInvoice } from "./orderInterface";

const CustomerInvoice = () => {
    const match = useMatch('/order/:id/invoice')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Order List', url: `/orders/1`, active: '' },
        { name: 'Order Detail', url: `/order/${match?.params.id}`, active: '' },
        { name: 'Seller Invoice', url: ``, active: 'not-allowed' },
    ]
    const { loading, setLoading, authState, authDispatch } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [orderD, setOrderD] = useState({} as orderInvoice)
    const orderListing = async () => {
        setLoading(true)
        try {
            let res = (await henceforthApi.Order.getOrderInvoiceDetails(match?.params.id)).data
            setOrderD(res)
        } catch (err: any) {
            console.log(err.response.body.error_description);
            handleError(err, '', authDispatch);
        } finally {
            setLoading(false)
        }
    }
    useEffect(() => {
        orderListing()
    }, [])
    return (<Fragment>
        {/* breadcrum  */}
        <BreadCrumb pathNameDeclare={breadCrumbPath} />
        {/* Page  */}
        {!loading &&
            <div className=' page-spacing'>
                <CustomerInvoicePdf dataHolder={orderD} />
            </div>}
    </Fragment>
    );
}
export default CustomerInvoice;