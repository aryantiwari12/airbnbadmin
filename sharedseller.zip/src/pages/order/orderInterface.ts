export interface innerCatType {
    name: string
}
export interface innerCatType2 {
    name: string
    image: string
}
export interface nameType {
    category_id: innerCatType,
    name: string,
    prodct_id:string,
    _id: string,
    images: Array<string>,
    reviews: any
}
export interface userProfileType {
    profile_pic: string,
    name: string,
    _id:string
}
export interface listingType {
    _id: string,
    order_id: string,
    user_id: userProfileType,
    total_price: number,
    order_status: string,
    total_earnings: number,
    product_id:any,
    seller_id: innerCatType2
    total_ratings: number,
    cancel_requested: boolean,
    ord_id: string,
    product_quantity:number,
    description:any,
    ratings:any,
    productId:any,
    quantity:number,
    product_price:any
    coupon_discount:number
}
export interface orderListType {
    total_count: number,
    data: Array<listingType>
}
export interface orderInvoice {
    address_id: {
        full_address: string
    },
    coupon_discount: number,
    created_at: string,
    delivery_date: null | string,
    delivery_price: number,
    order_id: string,
    invoice_id: string,
    order_object_id: string,
    order_status: string,
    price: number
    product_id: {
        brand_id: {
            created_at: string,
            is_deleted: boolean,
            name: string,
            updated_at: string,
            __v: number,
            _id: string,
        },
        subcategory: {
            name: string
        },
        services: { _id: string, content: string }[],
        description: string,
        prod_id: string,
        images: Array<string>,
        name: string,
        _id: string
    }
    quantity: number,
    reviews: null | string,
    seller_id: {
        country: null | string,
        country_code: string,
        full_address: string,
        company: string,
        image: string,
        name: string,
        phone_number: number,
        pin_code: string,
        state: string,
        _id: string,
    }
    shippo_data: null | string,
    total_price: number,
    tax_amount: number,
    tax_percantage: number,
    tax_no: string,
    updated_at: string,
    user_id: {
        country_code: string,
        email: string,
        name: string,
        phone_no: number,
        profile_pic: string,
        _id: string
    }
    _id: string,
    your_earning: number
}
export interface dataType {
    dataHolder: orderInvoice
}
export interface orderDetails {
    _id:string,
    actual_product_price:number,
    order_object_id: string,
    order_id: string,
    discount_price:number,
    admin_commision:number,
    cancel_request_accepted: boolean,
    cancel_requested: boolean,
    cancel_description: string,
    cancel_reason: string,
    discount_percantage:''
    product_id: {
        _id: string,
        prod_id:string,
        name: string,
        description: string,
        images: string[],
        ratings: { ratings: number, user_id: { name: string, profile_pic: string }, created_at: string, title: string, description: string }[],
        brand_id: {
            _id: string,
            name: string,
            created_at: string,
        }
    },
    user_id: {
        _id: string,
        profile_pic: string,
        name: string,
        country_code: string,
        email: string,
        phone_no: string
    },
    address_id: {
        full_address: string,
    },
    seller_id: {
        _id: string,
        name: string,
        image: string
    },
    quantity: number,
    price: number,
    delivery_price: number,
    coupon_discount: number,
    total_price: number,
    total_earnings:number,
    tax_percentage:number,
    shippo_data: string,
    order_status: string,
    delivery_date: string,
    updated_at: string,
    created_at: string
}