import { Link } from "react-router-dom"
import { Fragment, useContext, useEffect, useRef, useState } from "react";
import henceforthApi from "../../utils/henceforthApi";
import { strongPasswordValidation } from "../../utils/validations";
import { GlobalContext, handleError } from "../../context/Provider";
import Spinner from "../../components/common/spinner";
import Errormessage from "../../components/common/errormessage";
import BreadCrumb from "../../components/common/BreadCrumb";
import Inputs, { SaveCancelButton } from "../../components/common/Inputs";
type MultipleKeys = {
    oldPassword: string,
    newPassword: string,
    confirmNewPassword: string,
    loading: boolean
}
const ChangePassword = () => {
    const { authState, loading, setLoading, toastMessage, authDispatch } = useContext(GlobalContext)
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Change Password', url: ``, active: 'not-allowed' },
    ]
    henceforthApi.setToken(authState.access_token)
    const [firstEye, setFirstEye] = useState<boolean>(true);
    const [secondEye, setSecondEye] = useState<boolean>(true);
    const [thirdEye, setThirdEye] = useState<boolean>(true);
    const [oldPasswordErr, setOldPasswordErr] = useState('')
    const [newPasswordErr, setNewPasswordErr] = useState('')
    const [confirmPasswordErr, setConfirmPasswordErr] = useState('')
    const [state, setState] = useState({
        oldPassword: "",
        newPassword: "",
        confirmNewPassword: "",
        loading: false,
    } as MultipleKeys);
    const handleInput = (e: any) => {
        let name = e.target.name;
        let value = e.target.value;
        if (name === 'oldPassword') setOldPasswordErr('')
        if (name === 'newPassword') setNewPasswordErr('')
        if (name === 'confirmNewPassword')setConfirmPasswordErr('')
        setState({
            ...state,
            [name]: value,
        });

    };
    const handleSubmit = async (e: any) => {
        e.preventDefault();
        if (!state.oldPassword && !state.newPassword && !state.confirmNewPassword) {
            setOldPasswordErr('Old Password is required')
            setNewPasswordErr('New Password is required')
            setConfirmPasswordErr('Confirm Password is required')
            return
        }
        if (!state.oldPassword) return setOldPasswordErr('Old Password is required')
        if (!state.oldPassword.trim()) return setOldPasswordErr('Please enter a valid password')
        if (!state.newPassword) return setNewPasswordErr('New Password is required')
        if (!state.newPassword.trim()) return setNewPasswordErr('Please enter a valid password')
        if (!strongPasswordValidation(state.newPassword)) { return setNewPasswordErr("Password must be atleast 8 characters long and contain one uppercase and one lowercase character with special character and numbers") }
        if (state.newPassword !== state.confirmNewPassword) return setConfirmPasswordErr("New password and confirm password doesn't not match.")
        else if (state.newPassword === state.oldPassword) return setNewPasswordErr("New password must be different from old password")
        let items = {
            old_password: state.oldPassword,
            new_password: state.newPassword,
            language: "ENGLISH"
        }
        setLoading(true)
        try {
            let res = await henceforthApi.Auth.changePassword(items)
            toastMessage(res.data.message ? res.data.message : "password changed successfully")
            window.history.back()
        } catch (err) {
            handleError(err, 'active', authDispatch);

        } finally {
            setLoading(false)
        }
    }
    // const passwordCheck = () => {
        // if (state.newPassword.length < 7) {
        //     passwordErr.current.innerHTML = "Password must be atleast 8 characters long and contain one uppercase and one lowercase character with special character and numbers";
        // } else {
        //     passwordErr.current.innerHTML = "";
        // }
    // }
    // const passwordSame = (e: any) => {
        // if (state.newPassword !== e && state.confirmNewPassword) {
        //     passwordMatch.current.innerHTML = "Password must be same"
        // } else {
        //     passwordMatch.current.innerHTML = ""

        // }
    // }
    const eyeChanger = (selectEye: string) => {
        if (selectEye === "first") setFirstEye(!firstEye)
        else if(selectEye ==="second") setSecondEye(!secondEye)
        else if(selectEye ==="third") setThirdEye(!thirdEye)
    }
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* page  */}
            <div className='page-spacing' >
                <section className='change-password'>
                    <div className="container-fluid">
                        <div className="row justify-content-center">
                            <div className="col-sm-10 col-md-7 col-lg-6 col-xl-5 col-xxl-3 px-0">
                                <div className="common-card h-100">
                                    <div className="common-card-title">
                                        <h5>Change Password</h5>
                                    </div>
                                    <div className="common-card-content">
                                        <form onSubmit={handleSubmit}>
                                            {/* old Password */}
                                            <Inputs.InputWEye name="oldPassword" placeholder="Old Password" showHide={firstEye} selectEye="first" handleInput={handleInput} value={state.oldPassword} error={oldPasswordErr} passwordCheck={()=>{}} passwordSame={()=>{}}  onClick={eyeChanger} />
                                            {/* New Password */}
                                            <Inputs.InputWEye name="newPassword" placeholder="New Password" showHide={secondEye} selectEye="second" handleInput={handleInput} value={state.newPassword} error={newPasswordErr} onClick={eyeChanger} />
                                            {/* Confirm New Password */}
                                            <Inputs.InputWEye name="confirmNewPassword" placeholder="Confirm New Password" showHide={thirdEye} selectEye="third" handleInput={handleInput} value={state.confirmNewPassword} error={confirmPasswordErr} onClick={eyeChanger} />
                                            {/* Submit Button  */}
                                            <SaveCancelButton loading={loading} color="text-white" />
                                        </form>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </section>
            </div>
        </Fragment>
    )
}

export default ChangePassword;