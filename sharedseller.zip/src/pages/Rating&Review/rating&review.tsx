import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import defaultImage from '../../assets/images/pages/defaultImage.jpg'
import { Link, useLocation, useMatch } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import { Fragment, useContext, useEffect, useMemo, useState } from 'react'
import PaginationLayout from '../../components/common/PaginationLayout'
import { GlobalContext, handleError } from '../../context/Provider'
import henceforthApi from '../../utils/henceforthApi'
import Spinner from '../../components/common/spinner'
import moment from 'moment'
import BreadCrumb from '../../components/common/BreadCrumb'
import { numberWithCommas } from '../../utils/validations'
import AllFilter from '../../components/common/AllFilter'
import { orderListType } from '../order/orderInterface'
import COPY from "../../../src/assets/images/copy.png"
import { toast } from 'react-toastify'



const RatingReview = () => {
    let Limit = 10
    const location = useLocation()
    const match = useMatch('/ratings/:page')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Ratings & Reviews List', url: ``, active: 'not-allowed' }
    ]
    const newParam = new URLSearchParams(location.search);
    const { authState, loading, setLoading, authDispatch } = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [orderL, setOrderL] = useState({
        total_count: 0,
        data: [],
        
    } as orderListType)
    const orderListing = async () => {
        setLoading(true)
        try {
            let res = (await henceforthApi.Order.getOrderRatingReview(Number(match?.params.page) - 1, Limit, newParam.toString())).data
            setOrderL({
                total_count: res.total_count,
                data: res.data
            })
        } catch (err: any) {
            console.log("err", err.response.body.error_description);
            setOrderL({
                total_count: 0,
                data: []
            })
            handleError(err, 'active', authDispatch);
            // (err)
        } finally {
            setLoading(false)
        }
    }

    const copyText = (id: string) => {
        if (id) {
            navigator?.clipboard?.writeText(id)
            toast.success(`ProductId copy successfull`)
        }
    }

    const exportData = async (startDate: number, endDate: number) => {
        try {
            const apiRes = await henceforthApi.Order.export(startDate, endDate, '&order_status=DELIVERED')
            const data = apiRes.data.data
            console.log('data', data);
            const rows = [
                [
                    "Sr.",
                    "Order ID",
                    "Customer Detail",
                    "Product ID",
                    "Product Name",
                    "Order Price",
                    "Product Rating"
                ],
            ];
            if (Array.isArray(data)) {
                data.map((res: any, index: any) => {
                    return (
                        rows.push([
                            index + 1,
                            res?.order_id,
                            res?.user_id?.name,
                            res?.product_id?.prodct_id,
                            res?.product_id?.name,
                            res?.total_price,
                            res?.product_id?.reviews && res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings ? res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings : '0'
                        ]))
                })
            }
            console.log(rows);
            let csvContent =
                "data:text/csv;charset=utf-8," +
                rows.map((e) => e.join(",")).join("\n");
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `user_${moment().valueOf()}.csv`);
            document.body.appendChild(link); // Required for FF
            link.click(); // This will download the data file named "my_data.csv".
            let closeModal = document.getElementById("closeModal");
            if (closeModal) {
                closeModal.click();
            }
        } catch (err: any) {
            console.log(err.response.body.error_description);
            handleError(err, 'active', authDispatch);
        }

    }

    useEffect(() => {
        orderListing()
    }, [match?.params.page, newParam.get("search"), newParam.get("product_id"), newParam.get("min_price"), newParam.get("max_price")])
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* Page  */}
            <div className=' page-spacing'>
                <section className='products'>
                    <div className='product-detail-box'>
                        <AllFilter />
                        <div className="common-card">
                            <div className="common-card-title">
                                <h5>Rating & Review Listing </h5>
                            </div>
                            <div className="common-card-content">
                                {/* table */}
                                <div className='data-list-table table-responsive mb-3 text-center'>
                                    {loading ? <Spinner color={'text-success'} /> : <table className="table table-striped align-middle">
                                        <thead className=''>
                                            <tr>
                                                <th>Sr No.</th>
                                                {/* <th>Order ID</th> */}
                                                <th>Customer Detail</th>
                                                <th>Product ID</th>
                                                <th>Product Detail</th>
                                                <th>Product Price</th>
                                                {/* <th>Rating</th> */}
                                                <th>Rating & Review</th>
                                                <th>Action</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {Array.isArray(orderL.data) && orderL.data.length ? orderL?.data?.map((res, index: number) => {
                                                return (
                                                    <tr key={res._id}>
                                                        <td>{match?.params.page === "0"
                                                            ? index + 1
                                                            : (Number(match?.params.page) - 1) * Limit + (index + 1)}</td>
                                                        {/* <td>{res.order_id ? res.order_id : "Not Available"}</td> */}
                                                        <td className='product-image-table'>
                                                            <img src={res?.user_id?.profile_pic ? `${henceforthApi.API_FILE_ROOT_SMALL}${res.user_id?.profile_pic}` : defaultImage} alt="img" className='rounded-circle me-2' />
                                                            <span>{res?.user_id?.name ? res?.user_id?.name : "Not Avaiable"}</span>
                                                        </td>
                                                        <td>{res?.product_id?.prodct_id ? res?.product_id?.prodct_id : "Not Avaiable"} <img src={COPY}  style={{width:15}} onClick={()=>copyText(res?.product_id?.prodct_id )} role="button" data-toggle="tooltip" title={`${res?.product_id?.prodct_id }`} /></td>
                                                        <td className='product-image-table d-flex '>
                                                            <span className=''>
                                                                <img src={res?.product_id?.images[0] ? `${henceforthApi.API_FILE_ROOT_SMALL}${res.product_id.images[0]}` : defaultImage} alt={res.product_id.images[0]} className='rounded-circle me-2' />
                                                            </span>
                                                            <span className='d-flex flex-column justify-content-start'>
                                                                {/* <p>{res?.product_id?.category_id?.name ? res?.product_id?.category_id?.name : "Not Avaiable"}</p> */}
                                                                <p>{res?.product_id?.name?.length > 18 ? <Fragment>{res?.product_id?.name?.slice(0, 18)}...</Fragment> : res?.product_id?.name ? res?.product_id?.name : "Not Available"}</p>
                                                            </span>
                                                        </td>
                                                        <td><b>&#36;</b> {res?.product_id?.discount_price ? numberWithCommas(res?.product_id?.discount_price) : "Not Avaiable"}</td>
                                                        {/* <td>{res?.product_id?.reviews.length && res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings ? res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings : '0'}</td> */}
                                                        <td>
                                                            
                                                        {/* {res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.title && res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.description ? <span className='d-flex flex-column justify-content-start'> */}
                                                        {/* {res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings && res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.description ? <span className='d-flex'>
                                                                <p>{res?.product_id?.reviews.length && res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.title ? `${res?.product_id?.reviews.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.title?.slice(0,18)}...` : '0'}</p>
                                                                <p><i className="fa fa-star text-warning pe-1"></i>{res?.product_id?.reviews.length && res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings ? `${res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.ratings}.0` : '0'}</p>
                                                                <p className='ps-2'>{res?.product_id?.reviews.length && res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.description ? `${res?.product_id?.reviews?.find((reviews: any) => reviews?.user_id === res?.user_id?._id)?.description?.slice(0,18)}...` : '0'}</p>
                                                            </span>:'No Rating & Review'} */}
                                                           <p><i className="fa fa-star text-warning pe-1"></i>{res?.ratings?.toFixed(1)} {res?.description ? res?.description.slice(0,30) :'Not Avaiable' }</p> 
                                                        </td>
                                                        <td>
                                                            <div className="btn-group gap-2">
                                                                <Link className="btn btn-white btn-sm" to={`/product/${res?.product_id?._id}`}> <i className="fa fa-eye me-1"></i>View</Link>
                                                            </div>
                                                        </td>
                                                    </tr>
                                                )
                                            }) : <tr className='text-center'><td colSpan={8}>No Data Found</td></tr>}
                                        </tbody>
                                    </table>}
                                </div>
                                {/* pagination  */}
                                <PaginationLayout
                                    data={orderL.data}
                                    count={orderL.total_count}
                                    limit={Number(Limit)}
                                    page={Number(match?.params.page)}
                                />
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <DownloadFileModal exportData={useMemo(()=>exportData,[])} />
        </Fragment>
    )
}
export default RatingReview;