import '../../assets/styles/auth.scss'
import '../../assets/styles/pages.scss'
import defaultImage from '../../assets/images/pages/defaultImage.jpg'
import { Link, useLocation, useMatch } from 'react-router-dom'
import DownloadFileModal from '../../components/common/download-file-modal'
import { Fragment, useContext, useEffect, useMemo, useState } from 'react'
import PaginationLayout from '../../components/common/PaginationLayout'
import { GlobalContext, handleError } from '../../context/Provider'
import henceforthApi from '../../utils/henceforthApi'
import Spinner from '../../components/common/spinner'
import moment from 'moment'
import BreadCrumb from '../../components/common/BreadCrumb'
import { numberWithCommas } from '../../utils/validations'
import AllFilter from '../../components/common/AllFilter'
import { orderListType } from '../order/orderInterface'
import COPY from "../../../src/assets/images/copy.png"
import { toast } from 'react-toastify'


const ReviewsListing = () => {
    let Limit = 10
    const location = useLocation()
    const match = useMatch('/reviews/:order_id/:page')
    let breadCrumbPath = [
        { name: 'Home', url: `/`, active: '' },
        { name: 'Ratings & Reviews List', url: ``, active: 'not-allowed' }
    ]
    const newParam = new URLSearchParams(location.search);
    const { authState, loading, setLoading, authDispatch} = useContext(GlobalContext)
    henceforthApi.setToken(authState.access_token)
    const [orderL, setOrderL] = useState({
        total_count: 0,
        data: []
    } as orderListType)
    const orderListing = async () => {
        setLoading(true)
        try {
            let res = (await henceforthApi.Order.getOrderList(Number(match?.params.page) - 1, Limit, newParam.toString())).data
            setOrderL({
                total_count: res.total_count,
                data: res.data
            })
        } catch (err: any) {
            console.log("err", err.response.body.error_description);
            setOrderL({
                total_count: 0,
                data: []
            })
            handleError(err, 'active', authDispatch);
        } finally {
            setLoading(false)
        }
    }

    const copyText = (id: string,name:string) => {
        if (id) {
            navigator?.clipboard?.writeText(id)
            toast.success(`${name} copy successfull`)
        }
    }

    const exportData = async (startDate: number, endDate: number) => {
        try {
            // await henceforthApi.Order.export(startDate, endDate)
            const apiRes = {data:{data:[]}}
            const data = apiRes.data.data
            console.log('data', data);
            const rows = [
                [
                    "Sr.",
                    "Order ID",
                    "Customer Detail",
                    "Product ID",
                    "Product Detail",
                    "Order Price",
                    "Product Rating"
                ],
            ];
            if (Array.isArray(data)) {
                data.map((res: any, index: any) => {
                    return (
                        rows.push([
                            index + 1,
                            res?.order_id,
                            res?.user_id?.name,
                            res?.product_id?._id,
                            res?.product_id?.name,
                            res?.total_price,
                            res?.total_ratings
                        ]))
                })
            }
            console.log(rows);
            let csvContent =
                "data:text/csv;charset=utf-8," +
                rows.map((e) => e.join(",")).join("\n");
            var encodedUri = encodeURI(csvContent);
            var link = document.createElement("a");
            link.setAttribute("href", encodedUri);
            link.setAttribute("download", `user_${moment().valueOf()}.csv`);
            document.body.appendChild(link); // Required for FF
            link.click(); // This will download the data file named "my_data.csv".
            let closeModal = document.getElementById("closeModal");
            if (closeModal) {
                closeModal.click();
            }
        } catch (err: any) {
            console.log(err.response.body.error_description);
            handleError(err, 'active', authDispatch);
        }

    }

    useEffect(() => {
        orderListing()
    }, [match?.params.page, newParam.get("search"), newParam.get("product_id"),  newParam.get("min_price"), newParam.get("max_price")])
    return (
        <Fragment>
            {/* breadcrum  */}
            <BreadCrumb pathNameDeclare={breadCrumbPath} />
            {/* Page  */}
            <div className=' page-spacing'>
                <section className='products'>
                    <div className='product-detail-box'>
                        <AllFilter />
                        <div className="common-card">
                            <div className="common-card-title">
                                <h5>Rating & Review Listing</h5>
                            </div>
                            <div className="common-card-content">
                                {/* table */}
                                <div className='data-list-table table-responsive mb-3 text-center'>
                                    {loading ? <Spinner color={'text-success'} /> : <table className="table table-striped align-middle">
                                        <thead className=''>
                                            <tr>
                                                <th>Sr No.</th>
                                                <th>Order ID</th>
                                                <th>Customer Detail</th>
                                                {/* <th>Seller Detail</th> */}
                                                <th>Product ID</th>
                                                <th>Product Detail</th>
                                                <th>Product Price</th>
                                                <th>Product Rating</th>
                                                <th>Product Review</th>
                                                {/* <th>Order Status</th>
                                                <th>Earning</th>
                                                <th>Action</th> */}
                                            </tr>
                                        </thead>
                                        <tbody>
                                            {Array.isArray(orderL.data) && orderL.data.length ? orderL?.data?.map((res:any, index: number) => {
                                                return (
                                                    <tr key={res._id}>
                                                        <td>{match?.params.page === "0"
                                                            ? index + 1
                                                            : (Number(match?.params.page) - 1) * Limit + (index + 1)}</td>
                                                        <td>{res.order_id ? res.order_id : "Not Available"}<img src={COPY}  style={{width:15}} onClick={()=>res.copyText(res.order_id,"Order Id" )} role="button" data-toggle="tooltip" title={res.order_id}/></td>
                                                        <td className='product-image-table'>
                                                            <img src={res?.user_id?.profile_pic ? `${henceforthApi.API_FILE_ROOT_SMALL}${res.user_id?.profile_pic}` : defaultImage} alt="img" className='rounded-circle me-2' />
                                                            <span>{res?.user_id?.name ? res?.user_id?.name : "Not Avaiable"}</span>
                                                        </td>
                                                        <td>{res?.product_id?._id ? res?.product_id?._id : "Not Avaiable"}<img src={COPY}  style={{width:15}} onClick={()=>res.copyText(res.product_id?.prd_id,"Product Id" )} role="button" data-toggle="tooltip" title={res.product_id?.prd_id}  /></td>
                                                        <td className='product-image-table d-flex '>
                                                            <span className=''>
                                                                <img src={res?.product_id?.images[0] ? `${henceforthApi.API_FILE_ROOT_SMALL}${res.product_id.images[0]}` : defaultImage} alt={res.product_id.images[0]} className='rounded-circle me-2' />
                                                            </span>
                                                            <span className='d-flex flex-column justify-content-start'>
                                                                <p>{res?.product_id?.category_id?.name ? res?.product_id?.category_id?.name : "Not Avaiable"}</p>
                                                                <p>{res?.product_id?.name ? res?.product_id?.name : "Not Avaiable"}</p>
                                                            </span>
                                                        </td>
                                                        <td><b>&#36;</b> {res?.total_price ? numberWithCommas(res?.total_price) : "Not Avaiable"}</td>
                                                        <td>{res?.total_ratings ? res?.total_ratings : 'Not Available'}</td>
                                                        <td>
                                                            {Array.isArray(res?.product_id.reviews) && res?.product_id.reviews.length !==0 ? 
                                                            <div className="btn-group gap-2">
                                                                <Link className="btn btn-white btn-sm" to={`/product/${res?._id}`}> <i className="fa fa-eye me-1"></i>View</Link>
                                                            </div>
                                                            : '0'}
                                                        </td>
                                                    </tr>
                                                )
                                            }) : <tr className='text-center'><td colSpan={8}>No Data Found</td></tr>}



                                        </tbody>
                                    </table>}
                                    {/* {Array.isArray(orderD?.product_id?.ratings) && orderD?.product_id?.ratings.length ? orderD?.product_id?.ratings.map((res, index: number) => {
                                            let stared = [...Array(res?.ratings)].map((e, i) => <li key={i}><i className="fa fa-star text-warning"></i></li>)
                                            let staredOff = [...Array(5 - res?.ratings)].map((e, i) => <li key={i}><i className="fa fa-star text-muted"></i></li>)
                                            return (
                                                <Fragment key={index}>
                                                    <div className='rating-box'>
                                                        <div className="rating-username product-image-table d-flex gap-2 mb-2">
                                                            <img src={res?.user_detail?.profile_pic !== null && !res?.user_detail !== null ? `${henceforthApi.API_FILE_ROOT_MEDIUM}${res.user_detail.profile_pic}` : profile_img} className="border rounded-circle" alt="img" />
                                                            <div>
                                                                <p className='fw-bold'>{res?.user_detail?.name ? res?.user_detail?.name : "Not Available"}</p>
                                                                <ul className='list-unstyled d-flex gap-1 rating-icons m-0'>
                                                                    {stared}{staredOff}
                                                                </ul>
                                                            </div>
                                                        </div>
                                                        <div>

                                                            <p className='fw-bold'>{res?.title ? res?.title : "Not Avaialable"}</p>
                                                            <p className='my-1'> {res?.description ? res?.description : "Not Avaialable"} </p>
                                                            <p className='fw-bold'>{res?.created_at ? moment(Number(res?.created_at)).format('MMMM Do YYYY, h:mm:ss a') : "Not Avaiable"}</p>
                                                        </div>
                                                    </div>
                                                    <div className='divider my-3'></div>
                                                </Fragment>
                                            )
                                        }) : <p>Not Available </p>} */}
                                </div>
                                {/* pagination  */}
                                <PaginationLayout
                                    data={orderL.data}
                                    count={orderL.total_count}
                                    limit={Number(Limit)}
                                    page={Number(match?.params.page)}
                                />
                            </div>
                        </div>
                    </div>
                </section>
            </div>
            <DownloadFileModal exportData={useMemo(()=>exportData,[])} />
        </Fragment>
    )
}
export default ReviewsListing;