export default (props:any) => {
    return (
        <div className={`${props.class?'invalid-feedback':""} ${props.phone ?'mb-2 invalid-error-class':''}`}>
            {props.error}
        </div>
    )
}