import { Link } from "react-router-dom"
import { breadcrumArray } from "./commonInterface"

const BreadCrumb = (props: breadcrumArray) => {
    return (
        <section className="breadcrum-box">
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12">
                        <div className="d-flex justify-content-between align-items-center">
                            {/* title  */}
                            <div>
                                <h2>{props?.pathNameDeclare[props?.pathNameDeclare?.length - 1]?.name}</h2>
                                {/* breadcrum  */}
                                <nav aria-label="breadcrumb">
                                    <ol className="breadcrumb m-0">
                                        {props.pathNameDeclare.map((res, index: number) => <li className="breadcrumb-item " key={index}><Link to={`${res?.url}`} className={res?.active}>{res?.name}</Link></li>)}
                                    </ol>
                                </nav>
                            </div>
                            {props?.pathNameDeclare[props?.pathNameDeclare?.length - 1]?.name === 'Coupons list' && <div>
                                <Link to="/coupon/add" className="btn btn-white btn-sm"> <i className='fa fa-plus me-1'></i>Add</Link>
                            </div>}
                        </div>
                    </div>
                </div>
            </div>
        </section>
    )
}


export default BreadCrumb