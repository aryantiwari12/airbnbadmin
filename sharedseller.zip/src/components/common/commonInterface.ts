export interface menuMapList {
    pathname: string,
    path: string,
    fa: string,
    name: string
    onClick: string
    nested:Array<{path:string,pathname:string,name:string,fa:string}>
}
export interface pagination {
    count: number,
    data: Array<any>,
    page: number,
    limit: number,
  }

export interface breadcrumArray{
    pathNameDeclare:Array<{ name: string, url: string, active: string}>
}
