import { Fragment } from "react";

const TheFooter = () => {
    return (
        <Fragment>
            <div className="container-fluid">
                <div className="row">
                    <div className="col-md-12 text-center text-md-start">
                        {/* Copy Right Text  */}
                        <p>Copyright &copy; 2022 <span>Henceforth Ecommerce Seller Panel</span>. All Rights Reserved.</p>
                    </div>
                </div>
            </div>
        </Fragment>
    )
}
export default TheFooter;