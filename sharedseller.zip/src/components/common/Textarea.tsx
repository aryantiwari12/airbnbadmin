import Errormessage from "./errormessage";

export default (props: any) => {
    return <div className="form-fields-box mb-3">
        <label htmlFor={props.id} className='fw-bolder mb-1'>{props.label}</label>
        <textarea cols={props.col} rows={props.row} id={props.id} className={`form-control rounded-0 ${props.error ? 'is-invalid' : ''}`} name={props.name} placeholder={props.placeholder} value={props.value} onChange={(e: any) => { props.handleChange(e) }} />
        <Errormessage class={props.error} error={props.error} />
    </div>
}