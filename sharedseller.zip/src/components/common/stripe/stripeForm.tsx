import React from "react";
import { loadStripe } from "@stripe/stripe-js";
import { CardElement, Elements, useStripe, useElements } from "@stripe/react-stripe-js";

const CheckoutForm = () => {
  const stripe:any = useStripe();
  const elements:any = useElements();

  const handleSubmit = async (event:any) => {
    event.preventDefault();

    const { error, paymentMethod } = await stripe.createPaymentMethod({
      type: "card",
      card: elements.getElement(CardElement),
    });

    if (!error) {
      // send paymentMethod.id to your server for processing
    }
  };

  return (
    <form onSubmit={handleSubmit}>
      <CardElement />
      <button type="submit" disabled={!stripe}>
        Pay
      </button>
    </form>
  );
};
export default CheckoutForm;
{/* <div className='col-6'>
<Elements stripe={stripePromise}>
    <CheckoutForm />
</Elements>
</div> */}