import { Fragment } from "react";
import henceofrthEnums from "../../utils/henceofrthEnums";

export default ({ order_status, onClick, tracking }: any) => order_status !== henceofrthEnums.OrderStatus.DELIVERED ?
    <button type="button" className={`btn btn-theme text-white fw-bold ${order_status === henceofrthEnums.OrderStatus.PLACED ? 'bg-warning border-warning' : order_status === henceofrthEnums.OrderStatus.SHIPPED ? 'bg-success border-success' : ''} }`} onClick={() => onClick(order_status == henceofrthEnums.OrderStatus.PLACED ? henceofrthEnums.OrderStatus.SHIPPED : henceofrthEnums.OrderStatus.DELIVERED)} disabled={order_status === henceofrthEnums.OrderStatus.DELIVERED}>{order_status === henceofrthEnums.OrderStatus.PLACED ? 'Proceed to shipped' : 'Proceed to Delivered'}</button> : <Fragment></Fragment>
