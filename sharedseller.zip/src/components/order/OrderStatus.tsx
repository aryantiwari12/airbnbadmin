export default ({ order_status, width }: any) =>
    <span className={`badge-width text-white 
${order_status === "PLACED" ? 'text-bg-warning' :
            order_status === "PENDING_CANCELLATION" ? `text-bg-warning ${width}` :
                order_status === "CONFIRMED" ? 'text-bg-success' :
                    order_status === "DELIVERED" ? 'bg-success' : order_status === "CANCELLED" ? 'text-bg-danger' :
                        order_status === "SHIPPED" ? 'text-bg-primary' : ""}  px-2 py-half rounded-half fs-10 fw-semibold`}>
        {order_status && order_status === "PENDING_CANCELLATION" ? "PENDING CANCELLATION " : order_status}</span>
