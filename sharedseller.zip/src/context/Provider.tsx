import React, { createContext, ReactNode, SetStateAction, useEffect, useReducer, useState } from 'react'
import { useLocation, useNavigate } from 'react-router-dom';
import { toast, ToastContainer } from 'react-toastify';
import auth from './reducers/auth';
import logoutSuccess from "./actions/auth/logoutSuccess";
import henceforthApi from '../utils/henceforthApi';
import { ERROR_UNAUTHORIZED } from './actionTypes';

type ToastFunction = (msg: string) => void
type handleFunction = (name: string, value: string) => void
type paginationChange = (page: number) => void
type onFilterPriceHandler = (min_price: string, max_price: string) => void
interface CommonContextType {
    loading: boolean,
    setLoading: React.Dispatch<SetStateAction<boolean>>,
    authState: { access_token: string, name: string, email: string, phone_number: any, image: string, country_code: string, company: string, state: string, city: string, pin_code: string, apartment_number: string, full_address: string, email_verified: boolean },
    authDispatch: any,
    logOutNow: Function,
    toastMessage: ToastFunction,
    handleSearch: handleFunction,
    onChangePagination: paginationChange,
    onFilterPriceHandler: onFilterPriceHandler,
}


export const GlobalContext = createContext({} as CommonContextType);
export const handleError = (error: any, active: string, authDispatch: any) => {
    if (active === "active") toast.error((typeof error?.response?.body?.error_description === "string") ? error?.response?.body?.error_description : JSON.stringify(error?.response?.body?.error_description))
    if (error?.response?.body?.error === ERROR_UNAUTHORIZED) logoutSuccess({})(authDispatch);
}


export const downloadFile = (file_path: string) => {
    var a: any = document.createElement('a') as HTMLElement;
    a.href = file_path;
    a.target = "_blank";
    a.download = file_path.substr(file_path.lastIndexOf('/') + 1);
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
}

type GlobleContextProviderProps = {
    children: ReactNode;
}

function GlobalProvider(props: GlobleContextProviderProps) {
    const [authState, authDispatch] = useReducer(auth, {}, () => {
        const localAuthState = localStorage.getItem("authState");
        return localAuthState ? JSON.parse(localAuthState) : {}
    })
    const location = useLocation()
    const newParam = new URLSearchParams(location.search);

    const [loading, setLoading] = useState(false)
    // nestedData: Array<object>,
    // const [nestedData, setNestedData] = useState([] as Array<object>)

    const scrollToTop = () => {
        if (window) {
            window.scrollTo(0, 0);
        }
    }

    useEffect(scrollToTop, [location.pathname])
    useEffect(() => {
        localStorage.setItem("authState", JSON.stringify(authState))
    }, [authState]);
    useEffect(() => {
        if (!localStorage.getItem('authState')) {
            logOutNow()
        }
    }, [localStorage.getItem('authState')]);
    const navigate = useNavigate()
    
    const logOutNow = () => {
        logoutSuccess({})(authDispatch);
        navigate("/", { replace: true });
    };
    const toastMessage = (msg: string) => {
        toast.success(msg)
    }
    // const productFilter = async () => {
    //     try {
    //         let res = await henceforthApi.Common.getProductFilter()
    //         setNestedData(res.data.data)

    //     } catch (err) {
    //         console.log("err", err);
    //     }
    // }
    const handleSearch = (name: string, value: string) => {
        if (value) {
            if (name === "product_id") newParam.delete("search")
            if (name === "search") newParam.delete("product_id")
            if (name === "order_status") newParam.delete("payment_status")
            if (name === "payment_status") newParam.delete("order_status")
            if (name === 'start_date') newParam.delete('end_date')
            if (name === 'stock') newParam.delete('order_status'); newParam.delete('payment_status')
            if (name === 'order_status') newParam.delete('stock'); newParam.delete('payment_status')
            if (name === 'payment_status') newParam.delete('order_status'); newParam.delete('stock')
            newParam.set(name, value)
        } else {
            if (newParam.has(name)) {
                newParam.delete(name)
            }
            if (name === 'start_date') {
                newParam.delete('end_date')
            }

        }
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: "/orders/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: "/products/1",
                search: newParam.toString()
            })
        }
    }
    const onChangePagination = (page: number) => {
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: `/orders/${page}`,
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/coupons')) {
            navigate({
                pathname: `/coupons/${page}`,
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: `/products/${page}`,
                search: newParam.toString()
            })
        }

    }
    const onFilterPriceHandler = (min_price: string, max_price: string) => {
        if (min_price && max_price) {
            newParam.set("min_price", min_price)
            newParam.set("max_price", max_price)

        } else {
            if (newParam.has("min_price") && newParam.has("max_price")) {
                newParam.delete("min_price")
                newParam.delete("max_price")
            }
        }
        if (location.pathname.startsWith('/orders')) {
            navigate({
                pathname: "/orders/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/order/cancellation/requests')) {
            navigate({
                pathname: "/order/cancellation/requests/1?order_status=CANCELLED",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/ratings')) {
            navigate({
                pathname: "/ratings/1",
                search: newParam.toString()
            })
        } else if (location.pathname.startsWith('/earnings')) {
            navigate({
                pathname: "/earnings/1",
                search: newParam.toString()
            })
        } else {
            navigate({
                pathname: "/products/1",
                search: newParam.toString()
            })
        }
    }
    // useEffect(() => {
    //     productFilter();
    // }, [])
    return (
        <GlobalContext.Provider
            value={{ loading, setLoading, authState, onFilterPriceHandler, onChangePagination, handleSearch, authDispatch, logOutNow, toastMessage, }}>
            {props.children}
            <ToastContainer autoClose={2000} />
        </GlobalContext.Provider>
    )
}

export default GlobalProvider
