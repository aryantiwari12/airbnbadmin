import { STATIC_DATA_DASHBOARD, } from "../../../constants/actionTypes"

export default (payload:any) => (dispatch:any) => {
    dispatch({
        type: STATIC_DATA_DASHBOARD,
        payload: payload
    })
}