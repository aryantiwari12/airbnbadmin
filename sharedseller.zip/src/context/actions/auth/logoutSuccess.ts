import { LOGOUT_SUCCESS } from "../../../constants/actionTypes"

export default (payload:any) => (dispatch:any) => {
    dispatch({
        type: LOGOUT_SUCCESS,
        payload: payload
    })
}