import { PAGE_LIMIT_SUCCESS } from "../../../constants/actionTypes"

export default (payload:any) => (dispatch:any) => {
    dispatch({
        type: PAGE_LIMIT_SUCCESS,
        payload: payload
    })
}