import { STATIC_DATA_DASHBOARD, STATIC_DATA_NFTS, } from "../../../constants/actionTypes"

export default (payload:any) => (dispatch:any) => {
    dispatch({
        type: STATIC_DATA_NFTS,
        payload: payload
    })
}